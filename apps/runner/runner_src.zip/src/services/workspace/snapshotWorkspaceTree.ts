import { promises as fs } from "node:fs";
import path from "node:path";
import { isAllowedWorkspaceFile } from "./workspacePolicy.js";

export type WorkspaceSnapshotEntry =
    | {
    kind: "file";
    path: string;
    content: string;
}
    | {
    kind: "directory";
    path: string;
};

const BLOCKED_DIR_NAMES = new Set([
    ".git",
    ".svn",
    ".hg",
    "node_modules",
    "__MACOSX",
]);

function toPosixPath(input: string) {
    return input.replace(/\\/g, "/").replace(/^\/+/, "").replace(/\/+/g, "/");
}

function isSafeRelativePath(input: string) {
    const rel = toPosixPath(input).trim();

    if (!rel) return false;
    if (rel.startsWith("/")) return false;
    if (rel.includes("\0")) return false;
    if (rel.includes("//")) return false;

    const parts = rel.split("/");

    return parts.every((part) => {
        if (!part) return false;
        if (part === ".") return false;
        if (part === "..") return false;
        return true;
    });
}

function isAllowedWorkspaceDirectory(relPath: string) {
    const parts = toPosixPath(relPath).split("/").filter(Boolean);

    if (!parts.length) return false;

    return parts.every((part) => !BLOCKED_DIR_NAMES.has(part));
}

async function readTextFile(filePath: string) {
    const buffer = await fs.readFile(filePath);

    // Keep snapshots text-only. Linux lessons should only need text files.
    return buffer.toString("utf8");
}

export async function snapshotWorkspaceTree(
    workspaceRoot: string,
): Promise<WorkspaceSnapshotEntry[]> {
    const root = path.resolve(workspaceRoot);
    const entries: WorkspaceSnapshotEntry[] = [];

    async function walk(absDir: string, relDir: string) {
        const dirents = await fs.readdir(absDir, { withFileTypes: true });

        for (const dirent of dirents) {
            const relPath = toPosixPath(relDir ? `${relDir}/${dirent.name}` : dirent.name);

            if (!isSafeRelativePath(relPath)) continue;

            const absPath = path.resolve(root, relPath);

            // Do not allow symlink/path escape.
            if (!absPath.startsWith(`${root}${path.sep}`)) continue;

            if (dirent.isDirectory()) {
                if (!isAllowedWorkspaceDirectory(relPath)) continue;

                entries.push({
                    kind: "directory",
                    path: relPath,
                });

                await walk(absPath, relPath);
                continue;
            }

            if (!dirent.isFile()) continue;
            if (!isAllowedWorkspaceFile(relPath)) continue;

            entries.push({
                kind: "file",
                path: relPath,
                content: await readTextFile(absPath),
            });
        }
    }

    await walk(root, "");

    return entries.sort((a, b) => {
        const pathCmp = a.path.localeCompare(b.path);
        if (pathCmp !== 0) return pathCmp;

        const ak = a.kind ?? "file";
        const bk = b.kind ?? "file";

        if (ak === bk) return 0;
        return ak === "directory" ? -1 : 1;
    });
}
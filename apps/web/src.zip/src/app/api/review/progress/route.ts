import { prisma } from "@/lib/prisma";
import {
    actorKeyOf,
    ensureGuestId,
    getActor,
} from "@/lib/practice/actor";
import {
    bodyJsonResponse,
    bodyJsonWithGuestCookie,
    enforceSameOriginPost,
    exceedsContentLength,
    getClientIp,
    readJsonSafe,
} from "@/lib/practice/api/shared/http";
import { pickLocale } from "@/lib/review/api/shared/schemas";
import type { ReviewProgressState, ReviewTopicProgress } from "@/lib/review/progressTypes";
import {
    mergeTopicProgressStates,
    normalizeProgressTopics,
    normalizeTopicProgressKey,
} from "@/lib/review/progressTopicKeys";
import {
    REVIEW_PROGRESS_LIMITS,
    ReviewProgressWriteSchema,
} from "@/lib/review/api/progress/schemas";
import { resolveReviewModuleForSubject } from "@/lib/review/api/shared/modules";
import { awardReviewProgressGamification } from "@/lib/gamification/awardReviewProgressGamification";
import { rateLimit } from "@/lib/security/ratelimit";

async function resolveReviewProgressScope(args: {
    subjectSlug: string;
    moduleSlug: string;
}) {
    const actor0 = await getActor();
    const { actor, setGuestId } = ensureGuestId(actor0);

    const resolved = await resolveReviewModuleForSubject(prisma, {
        subjectSlug: args.subjectSlug,
        moduleSlug: args.moduleSlug,
    });

    return { actor, setGuestId, resolved };
}







function numericVersion(value: unknown) {
    const n = Number(value ?? 0);
    return Number.isFinite(n) ? n : 0;
}

function isEmptyRecord(value: unknown) {
    return (
        !value ||
        (typeof value === "object" &&
            !Array.isArray(value) &&
            Object.keys(value as Record<string, unknown>).length === 0)
    );
}

function isAuthoritativeModuleReset(args: {
    previous: ReviewProgressState;
    incoming: ReviewProgressState;
}) {
    const previousVersion = numericVersion(args.previous.quizVersion);
    const incomingVersion = numericVersion(args.incoming.quizVersion);

    return (
        incomingVersion > previousVersion &&
        args.incoming.moduleCompleted === false &&
        !args.incoming.moduleCompletedAt &&
        isEmptyRecord(args.incoming.topics)
    );
}

function isAuthoritativeTopicReset(args: {
    previousTopic: ReviewTopicProgress | undefined;
    incomingTopic: ReviewTopicProgress;
}) {
    const incomingVersion = numericVersion(args.incomingTopic.quizVersion);
    const previousVersion = numericVersion(args.previousTopic?.quizVersion);

    return (
        incomingVersion > previousVersion &&
        args.incomingTopic.completed === false &&
        !args.incomingTopic.completedAt
    );
}


function getSaveRevision(state: any) {
    const n = Number(state?.__saveRevision ?? 0);
    return Number.isFinite(n) ? n : 0;
}

function stateBytes(state: any) {
    try {
        return JSON.stringify(state ?? null).length;
    } catch {
        return 0;
    }
}

function timeMs(value: unknown) {
    const n = Number(new Date(String(value ?? "")));
    return Number.isFinite(n) ? n : 0;
}

function pickLatestIso(a: unknown, b: unknown) {
    const aMs = timeMs(a);
    const bMs = timeMs(b);
    if (!aMs && !bMs) return undefined;
    return bMs >= aMs ? (b as string | undefined) : (a as string | undefined);
}

function mergeReviewProgressForSave(args: {
    previousState: ReviewProgressState | null;
    incomingState: ReviewProgressState;
    saveRevision: number;
}) {
    const previous = normalizeProgressTopics(args.previousState ?? {});
    const incoming = normalizeProgressTopics(args.incomingState ?? {});

    /**
     * Reset Module is authoritative.
     *
     * Do not merge old topics/moduleCompleted back in.
     */
    if (isAuthoritativeModuleReset({ previous, incoming })) {
        return {
            ...incoming,
            quizVersion: Math.max(
                numericVersion(previous.quizVersion),
                numericVersion(incoming.quizVersion),
            ),
            moduleCompleted: false,
            moduleCompletedAt: undefined,
            topics: {},
            activeTopicId: normalizeTopicProgressKey(
                incoming.activeTopicId ?? previous.activeTopicId,
            ),
            assignmentSessionId:
                incoming.assignmentSessionId ?? previous.assignmentSessionId,
            __saveRevision: args.saveRevision,
        } as ReviewProgressState & { __saveRevision: number };
    }

    const nextTopics: Record<string, ReviewTopicProgress> = {
        ...(previous.topics ?? {}),
    };

    let hasAuthoritativeTopicReset = false;

    const incomingTopicEntries = Object.entries(
        incoming.topics ?? {},
    ) as Array<[string, ReviewTopicProgress]>;

    for (const [topicKey, incomingTopic] of incomingTopicEntries) {
        const normalizedTopicKey = normalizeTopicProgressKey(topicKey);
        const previousTopic = nextTopics[normalizedTopicKey];

        if (
            isAuthoritativeTopicReset({
                previousTopic,
                incomingTopic,
            })
        ) {
            hasAuthoritativeTopicReset = true;

            /**
             * Reset Topic / Reset Quiz is authoritative for completion maps.
             * The incoming state already contains the correct remaining
             * runtime/tool state after reset.
             */
            nextTopics[normalizedTopicKey] = incomingTopic;
            continue;
        }

        const mergedTopic = mergeTopicProgressStates(previousTopic, incomingTopic);

        if (previousTopic?.completed || incomingTopic.completed) {
            mergedTopic.completed = true;
        }

        mergedTopic.completedAt = pickLatestIso(
            previousTopic?.completedAt,
            incomingTopic.completedAt,
        );

        nextTopics[normalizedTopicKey] = mergedTopic;
    }

    const incomingExplicitlyClearsModule =
        incoming.moduleCompleted === false && !incoming.moduleCompletedAt;

    const moduleCompleted =
        hasAuthoritativeTopicReset || incomingExplicitlyClearsModule
            ? false
            : Boolean(previous.moduleCompleted || incoming.moduleCompleted);

    const moduleCompletedAt =
        hasAuthoritativeTopicReset || incomingExplicitlyClearsModule
            ? undefined
            : pickLatestIso(previous.moduleCompletedAt, incoming.moduleCompletedAt);

    return {
        ...previous,
        ...incoming,
        quizVersion: Math.max(
            numericVersion(previous.quizVersion),
            numericVersion(incoming.quizVersion),
        ),
        moduleCompleted,
        moduleCompletedAt,
        activeTopicId: normalizeTopicProgressKey(
            incoming.activeTopicId ?? previous.activeTopicId,
        ),
        assignmentSessionId:
            incoming.assignmentSessionId ?? previous.assignmentSessionId,
        topics: nextTopics,
        __saveRevision: args.saveRevision,
    } as ReviewProgressState & { __saveRevision: number };
}


export async function GET(req: Request) {
    const { searchParams } = new URL(req.url);
    const subjectSlug = (searchParams.get("subjectSlug") ?? "").trim();
    const moduleSlug = (
        searchParams.get("moduleSlug") ??
        searchParams.get("moduleId") ??
        ""
    ).trim();
    const locale = pickLocale(searchParams.get("locale"), "en");

    if (!subjectSlug || !moduleSlug) {
        return bodyJsonResponse({ message: "Missing subjectSlug/moduleId." }, 400);
    }

    const { actor, setGuestId, resolved } = await resolveReviewProgressScope({
        subjectSlug,
        moduleSlug,
    });

    if (!resolved.ok) {
        return bodyJsonWithGuestCookie(
            {
                message: resolved.message,
                detail: resolved.detail,
            },
            resolved.statusCode,
            setGuestId,
        );
    }

    const actorKey = actorKeyOf(actor);

    const row = await prisma.reviewProgress.findUnique({
        where: {
            actorKey_subjectSlug_moduleId_locale: {
                actorKey,
                subjectSlug,
                moduleId: resolved.module.slug,
                locale,
            },
        },
    });

    const state = (row?.state ?? null) as ReviewProgressState | null;

    return bodyJsonWithGuestCookie(
        {
            progress: state,
        },
        200,
        setGuestId,
    );
}

export async function POST(req: Request) {
    return PUT(req);
}

export async function PUT(req: Request) {
    if (!enforceSameOriginPost(req)) {
        return bodyJsonResponse({ message: "Forbidden." }, 403);
    }

    if (exceedsContentLength(req, REVIEW_PROGRESS_LIMITS.maxPayloadBytes)) {
        return bodyJsonResponse(
            {
                message: `Payload exceeds the ${REVIEW_PROGRESS_LIMITS.maxPayloadBytes} byte limit.`,
            },
            413,
        );
    }

    const body = await readJsonSafe(req);
    if (!body) {
        return bodyJsonResponse({ message: "Invalid JSON body." }, 400);
    }

    const parsed = ReviewProgressWriteSchema.safeParse(body);
    if (!parsed.success) {
        return bodyJsonResponse(
            {
                message: "Invalid body.",
                issues: parsed.error.issues,
            },
            400,
        );
    }

    const subjectSlug = parsed.data.subjectSlug;
    const moduleSlug = parsed.data.moduleRef;
    const locale = pickLocale(parsed.data.locale, "en");
    const state = parsed.data.state;

    const { actor, setGuestId, resolved } = await resolveReviewProgressScope({
        subjectSlug,
        moduleSlug,
    });

    if (!resolved.ok) {
        return bodyJsonWithGuestCookie(
            {
                message: resolved.message,
                detail: resolved.detail,
            },
            resolved.statusCode,
            setGuestId,
        );
    }

    const actorKey = actorKeyOf(actor);
    const rateLimitActorKey = actorKey === "g:missing" ? getClientIp(req) : actorKey;

    try {
        const rl = await rateLimit(`review-progress:${rateLimitActorKey}`, {
            bucket: "review-progress-save",
            limit: 180,
            window: "60 s",
        });

        if (!rl.ok) {
            const res = bodyJsonWithGuestCookie(
                {
                    message: "Too many requests.",
                },
                429,
                setGuestId,
            );
            const retryAfter = Math.max(1, Math.ceil((rl.resetMs - Date.now()) / 1000));
            res.headers.set("Retry-After", String(retryAfter));
            return res;
        }
    } catch {
        return bodyJsonWithGuestCookie(
            {
                message: "Service unavailable.",
            },
            503,
            setGuestId,
        );
    }

    const previous = await prisma.reviewProgress.findUnique({
        where: {
            actorKey_subjectSlug_moduleId_locale: {
                actorKey,
                subjectSlug,
                moduleId: resolved.module.slug,
                locale,
            },
        },
        select: {
            state: true,
        },
    });

    const previousState = (previous?.state ?? null) as ReviewProgressState | null;
    const existingRevision = getSaveRevision(previousState);
    const incomingRevision = getSaveRevision(state);

    if (previous && incomingRevision < existingRevision) {
        console.warn("[review-progress] ignored stale save", {
            actorKey,
            subjectSlug,
            moduleId: resolved.module.slug,
            locale,
            incomingRevision,
            existingRevision,
            incomingBytes: stateBytes(state),
            existingBytes: stateBytes(previousState),
        });

        return bodyJsonWithGuestCookie(
            {
                ok: false,
                ignored: true,
                reason: "stale_revision",
                incomingRevision,
                existingRevision,
            },
            409,
            setGuestId,
        );
    }

    const nextRevision = Math.max(existingRevision + 1, incomingRevision, Date.now());
    const stateToPersist = mergeReviewProgressForSave({
        previousState,
        incomingState: state as ReviewProgressState,
        saveRevision: nextRevision,
    });

    const saved = await prisma.reviewProgress.upsert({
        where: {
            actorKey_subjectSlug_moduleId_locale: {
                actorKey,
                subjectSlug,
                moduleId: resolved.module.slug,
                locale,
            },
        },
        create: {
            actorKey,
            subjectSlug,
            moduleId: resolved.module.slug,
            locale,
            state: stateToPersist,
        },
        update: {
            state: stateToPersist,
        },
        select: {
            id: true,
            updatedAt: true,
            state: true,
        },
    });

    let gamification = null;

    try {
        gamification = await awardReviewProgressGamification({
            prisma,
            actor,
            subjectSlug,
            moduleSlug: resolved.module.slug,
            previousState,
            nextState: stateToPersist,
        });
    } catch (e) {
        console.error("awardReviewProgressGamification failed", {
            actorKey,
            subjectSlug,
            moduleSlug: resolved.module.slug,
            error: e,
        });
    }

    return bodyJsonWithGuestCookie(
        {
            ok: true,
            saved,
            state: saved.state,
            gamification,
        },
        200,
        setGuestId,
    );
}

export async function DELETE(req: Request) {
    if (!enforceSameOriginPost(req)) {
        return bodyJsonResponse({ message: "Forbidden." }, 403);
    }

    const { searchParams } = new URL(req.url);
    const subjectSlug = (searchParams.get("subjectSlug") ?? "").trim();
    const moduleSlug = (
        searchParams.get("moduleSlug") ??
        searchParams.get("moduleId") ??
        ""
    ).trim();
    const locale = pickLocale(searchParams.get("locale"), "en");

    if (!subjectSlug || !moduleSlug) {
        return bodyJsonResponse({ message: "Missing subjectSlug/moduleId." }, 400);
    }

    const { actor, setGuestId, resolved } = await resolveReviewProgressScope({
        subjectSlug,
        moduleSlug,
    });

    if (!resolved.ok) {
        return bodyJsonWithGuestCookie(
            {
                message: resolved.message,
                detail: resolved.detail,
            },
            resolved.statusCode,
            setGuestId,
        );
    }

    const actorKey = actorKeyOf(actor);

    await prisma.$transaction([
        prisma.reviewProgress.deleteMany({
            where: {
                actorKey,
                subjectSlug,
                moduleId: resolved.module.slug,
                locale,
            },
        }),
        prisma.reviewQuizInstance.deleteMany({
            where: {
                actorKey,
                AND: [
                    { quizKey: { startsWith: "review-quiz|" } },
                    { quizKey: { contains: `|subject=${subjectSlug}|` } },
                    { quizKey: { contains: `|module=${resolved.module.slug}|` } },
                ],
            },
        }),
    ]);

    return bodyJsonWithGuestCookie(
        {
            ok: true,
        },
        200,
        setGuestId,
    );
}

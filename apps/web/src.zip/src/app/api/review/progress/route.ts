import { prisma } from "@/lib/prisma";
import {
    actorKeyOf,
    ensureGuestId,
    getActor,
} from "@/lib/practice/actor";
import {
    bodyJsonResponse,
    bodyJsonWithGuestCookie,
    enforceSameOriginPost,
    readJsonSafe,
} from "@/lib/practice/api/shared/http";
import { pickLocale } from "@/lib/review/api/shared/schemas";
import type { ReviewProgressState } from "@/lib/subjects/progressTypes";
import { ReviewProgressWriteSchema } from "@/lib/review/api/progress/schemas";
import { resolveReviewModuleForSubject } from "@/lib/review/api/shared/modules";
import { awardReviewProgressGamification } from "@/lib/gamification/awardReviewProgressGamification";

async function resolveReviewProgressScope(args: {
    subjectSlug: string;
    moduleSlug: string;
}) {
    const actor0 = await getActor();
    const { actor, setGuestId } = ensureGuestId(actor0);

    const resolved = await resolveReviewModuleForSubject(prisma, {
        subjectSlug: args.subjectSlug,
        moduleSlug: args.moduleSlug,
    });

    return { actor, setGuestId, resolved };
}

function getSaveRevision(state: any) {
    const n = Number(state?.__saveRevision ?? 0);
    return Number.isFinite(n) ? n : 0;
}

function stateBytes(state: any) {
    try {
        return JSON.stringify(state ?? null).length;
    } catch {
        return 0;
    }
}

function topicKeys(state: any) {
    return Object.keys(state?.topics ?? {});
}

function topicSummary(state: any) {
    return Object.fromEntries(
        Object.entries((state?.topics ?? {}) as Record<string, any>).map(([topicKey, topic]) => [
            topicKey,
            {
                runtimeExerciseKeys: Object.keys(topic?.runtimeStateV2?.exercises ?? {}),
                runtimeCardKeys: Object.keys(topic?.runtimeStateV2?.cards ?? {}),
                toolStateKeys: Object.keys(topic?.toolState ?? {}),
                quizStateKeys: Object.keys(topic?.quizState ?? {}),
            },
        ]),
    );
}

export async function GET(req: Request) {
    const { searchParams } = new URL(req.url);
    const subjectSlug = (searchParams.get("subjectSlug") ?? "").trim();
    const moduleSlug = (
        searchParams.get("moduleSlug") ??
        searchParams.get("moduleId") ??
        ""
    ).trim();
    const locale = pickLocale(searchParams.get("locale"), "en");

    if (!subjectSlug || !moduleSlug) {
        return bodyJsonResponse({ message: "Missing subjectSlug/moduleId." }, 400);
    }

    const { actor, setGuestId, resolved } = await resolveReviewProgressScope({
        subjectSlug,
        moduleSlug,
    });

    if (!resolved.ok) {
        return bodyJsonWithGuestCookie(
            {
                message: resolved.message,
                detail: resolved.detail,
            },
            resolved.statusCode,
            setGuestId,
        );
    }

    const actorKey = actorKeyOf(actor);

    const row = await prisma.reviewProgress.findUnique({
        where: {
            actorKey_subjectSlug_moduleId_locale: {
                actorKey,
                subjectSlug,
                moduleId: resolved.module.slug,
                locale,
            },
        },
    });

    const state = (row?.state ?? null) as ReviewProgressState | null;

    console.log("[review-progress] loaded", {
        actorKey,
        subjectSlug,
        moduleId: resolved.module.slug,
        locale,
        hasState: Boolean(state),
        saveRevision: getSaveRevision(state),
        stateBytes: stateBytes(state),
        topicKeys: topicKeys(state),
        topicSummary: topicSummary(state),
    });

    return bodyJsonWithGuestCookie(
        {
            progress: state,
        },
        200,
        setGuestId,
    );
}

export async function POST(req: Request) {
    return PUT(req);
}

export async function PUT(req: Request) {
    if (!enforceSameOriginPost(req)) {
        return bodyJsonResponse({ message: "Forbidden." }, 403);
    }

    const body = await readJsonSafe(req);
    if (!body) {
        return bodyJsonResponse({ message: "Invalid JSON body." }, 400);
    }

    const parsed = ReviewProgressWriteSchema.safeParse(body);
    if (!parsed.success) {
        return bodyJsonResponse(
            {
                message: "Invalid body.",
                issues: parsed.error.issues,
            },
            400,
        );
    }

    const subjectSlug = parsed.data.subjectSlug;
    const moduleSlug = parsed.data.moduleRef;
    const locale = pickLocale(parsed.data.locale, "en");
    const state = parsed.data.state;

    const { actor, setGuestId, resolved } = await resolveReviewProgressScope({
        subjectSlug,
        moduleSlug,
    });

    if (!resolved.ok) {
        return bodyJsonWithGuestCookie(
            {
                message: resolved.message,
                detail: resolved.detail,
            },
            resolved.statusCode,
            setGuestId,
        );
    }

    const actorKey = actorKeyOf(actor);

    const previous = await prisma.reviewProgress.findUnique({
        where: {
            actorKey_subjectSlug_moduleId_locale: {
                actorKey,
                subjectSlug,
                moduleId: resolved.module.slug,
                locale,
            },
        },
        select: {
            state: true,
        },
    });

    const previousState = (previous?.state ?? null) as ReviewProgressState | null;
    const existingRevision = getSaveRevision(previousState);
    const incomingRevision = getSaveRevision(state);

    if (previous && incomingRevision < existingRevision) {
        console.warn("[review-progress] ignored stale save", {
            actorKey,
            subjectSlug,
            moduleId: resolved.module.slug,
            locale,
            incomingRevision,
            existingRevision,
            incomingBytes: stateBytes(state),
            existingBytes: stateBytes(previousState),
            incomingTopicKeys: topicKeys(state),
            existingTopicKeys: topicKeys(previousState),
            incomingTopicSummary: topicSummary(state),
            existingTopicSummary: topicSummary(previousState),
        });

        return bodyJsonWithGuestCookie(
            {
                ok: true,
                ignored: true,
                reason: "stale_save",
                incomingRevision,
                existingRevision,
            },
            200,
            setGuestId,
        );
    }

    const saved = await prisma.reviewProgress.upsert({
        where: {
            actorKey_subjectSlug_moduleId_locale: {
                actorKey,
                subjectSlug,
                moduleId: resolved.module.slug,
                locale,
            },
        },
        create: {
            actorKey,
            subjectSlug,
            moduleId: resolved.module.slug,
            locale,
            state,
        },
        update: {
            state,
        },
        select: {
            id: true,
            updatedAt: true,
        },
    });

    console.log("[review-progress] saved", {
        actorKey,
        subjectSlug,
        moduleId: resolved.module.slug,
        locale,
        updatedAt: saved.updatedAt,
        saveRevision: incomingRevision,
        stateBytes: stateBytes(state),
        topicKeys: topicKeys(state),
        topicSummary: topicSummary(state),
    });

    let gamification = null;

    try {
        gamification = await awardReviewProgressGamification({
            prisma,
            actor,
            subjectSlug,
            moduleSlug: resolved.module.slug,
            previousState,
            nextState: state,
        });
    } catch (e) {
        console.error("awardReviewProgressGamification failed", {
            actorKey,
            subjectSlug,
            moduleSlug: resolved.module.slug,
            error: e,
        });
    }

    return bodyJsonWithGuestCookie(
        {
            ok: true,
            saved,
            gamification,
        },
        200,
        setGuestId,
    );
}

export async function DELETE(req: Request) {
    if (!enforceSameOriginPost(req)) {
        return bodyJsonResponse({ message: "Forbidden." }, 403);
    }

    const { searchParams } = new URL(req.url);
    const subjectSlug = (searchParams.get("subjectSlug") ?? "").trim();
    const moduleSlug = (
        searchParams.get("moduleSlug") ??
        searchParams.get("moduleId") ??
        ""
    ).trim();
    const locale = pickLocale(searchParams.get("locale"), "en");

    if (!subjectSlug || !moduleSlug) {
        return bodyJsonResponse({ message: "Missing subjectSlug/moduleId." }, 400);
    }

    const { actor, setGuestId, resolved } = await resolveReviewProgressScope({
        subjectSlug,
        moduleSlug,
    });

    if (!resolved.ok) {
        return bodyJsonWithGuestCookie(
            {
                message: resolved.message,
                detail: resolved.detail,
            },
            resolved.statusCode,
            setGuestId,
        );
    }

    const actorKey = actorKeyOf(actor);

    await prisma.$transaction([
        prisma.reviewProgress.deleteMany({
            where: {
                actorKey,
                subjectSlug,
                moduleId: resolved.module.slug,
                locale,
            },
        }),
        prisma.reviewQuizInstance.deleteMany({
            where: {
                actorKey,
                AND: [
                    { quizKey: { startsWith: "review-quiz|" } },
                    { quizKey: { contains: `|subject=${subjectSlug}|` } },
                    { quizKey: { contains: `|module=${resolved.module.slug}|` } },
                ],
            },
        }),
    ]);

    return bodyJsonWithGuestCookie(
        {
            ok: true,
        },
        200,
        setGuestId,
    );
}

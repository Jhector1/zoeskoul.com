import type { CodeExpectedInput } from "@/lib/practice/api/validate/schemas";
import type { InteractiveLanguage } from "@zoeskoul/code-contracts";
import type { SqlDialect } from "@/lib/practice/types";
import {
    makeProgrammingExpected,
    makeSqlExpected,
    parseCodeExpected,
    toProgrammingCodeTests,
    toSqlCodeTests,
    type ProgrammingCodeTest,
    type SemanticCheck,
    type ProgrammingWorkspaceExpectations,
    type SqlExpectedTest,
    type SqlExpectedTable,
    type SqlRuntimeSpec as SharedSqlRuntimeSpec,
} from "@zoeskoul/practice-checks";

export type CodeTest = {
    stdin?: string;
    stdout: string;
    match?: "exact" | "includes";
};

export type CodeExpected = {
    kind: "code_input";
    language?: string;
    tests: CodeTest[];
    stdin?: string;
    stdout?: string;
    solutionCode?: string;
};

type ProgrammingLanguage = InteractiveLanguage;

export type SqlCell = string | number | boolean | null;
export type { ProgrammingCodeTest, SemanticCheck, SqlExpectedTable };
export type SqlCodeTest = SqlExpectedTest;
export type SqlRuntimeSpec = SharedSqlRuntimeSpec;

export type SqlMakeCodeExpectedArgs = {
    kind?: "code_input";
    language: "sql";
    fixedSqlDialect?: SqlDialect;
    runtime?: SqlRuntimeSpec;
    tests?: SqlCodeTest[];
    solutionCode: string;
};

type ProgrammingCodeExpected = ReturnType<typeof makeProgrammingExpected>;
type SqlCodeExpected = ReturnType<typeof makeSqlExpected>;

export type ProgrammingMakeCodeExpectedArgs = {
    kind?: "code_input";
    language?: ProgrammingLanguage;
    checkMode?: "stdout" | "semantic";
    stdin?: string;
    stdout?: string;
    match?: "exact" | "includes";
    tests?: ProgrammingCodeTest[];
    semanticChecks?: SemanticCheck[];
    sourceChecks?: unknown[];
    workspaceExpectations?: ProgrammingWorkspaceExpectations;
    solutionCode?: string;
};

export function terminalFence(stdin: string, stdout: string) {
    return String.raw`~~~terminal
$ input
${stdin.trimEnd()}

$ output
${stdout.trimEnd()}
~~~`;
}


function getShellTaskExpectedMeta(expected: any) {
    const recipeType =
        typeof expected?.recipeType === "string"
            ? expected.recipeType
            : typeof expected?.recipe?.type === "string"
                ? expected.recipe.type
                : "";

    const shellTaskMode =
        typeof expected?.shellTaskMode === "string"
            ? expected.shellTaskMode
            : typeof expected?.recipe?.mode === "string"
                ? expected.recipe.mode
                : "";

    if (recipeType !== "shell_task") {
        return {};
    }

    return {
        recipeType: "shell_task",
        ...(shellTaskMode ? { shellTaskMode } : {}),
    };
}
function isTerminalWorkspaceShellTaskExpected(expected: any) {
    const recipeType =
        typeof expected?.recipeType === "string"
            ? expected.recipeType
            : typeof expected?.recipe?.type === "string"
                ? expected.recipe.type
                : "";

    const shellTaskMode =
        typeof expected?.shellTaskMode === "string"
            ? expected.shellTaskMode
            : typeof expected?.recipe?.mode === "string"
                ? expected.recipe.mode
                : "";

    return recipeType === "shell_task" && shellTaskMode === "terminal_workspace";
}

function normalizeTerminalWorkspaceShellTaskExpectedForSave(expected: any) {
    if (!isTerminalWorkspaceShellTaskExpected(expected)) {
        return null;
    }

    const workspaceExpectations =
        expected?.workspaceExpectations ??
        expected?.workspace?.workspaceExpectations ??
        null;

    if (!workspaceExpectations || typeof workspaceExpectations !== "object") {
        throw new Error(
            `Generator bug: shell_task terminal_workspace expected is missing workspaceExpectations. expected=${JSON.stringify(
                expected,
                null,
                2,
            )}`,
        );
    }

    return {
        kind: "code_input",
        strategy: "programming",
        language: "bash",
        checkMode: "stdout",
        recipeType: "shell_task",
        shellTaskMode: "terminal_workspace",
        workspaceExpectations,
        tests: [
            {
                stdout: "",
                match: "includes",
            },
        ],
        ...(Array.isArray(expected?.sourceChecks) && expected.sourceChecks.length
            ? { sourceChecks: expected.sourceChecks.filter(Boolean) }
            : {}),
    };
}
export function makeCodeExpected(args: ProgrammingMakeCodeExpectedArgs): CodeExpectedInput;
export function makeCodeExpected(args: SqlMakeCodeExpectedArgs): CodeExpectedInput;
export function makeCodeExpected(
    args: ProgrammingMakeCodeExpectedArgs | SqlMakeCodeExpectedArgs,
): CodeExpectedInput {
    if (args.language === "sql") {
        return makeSqlExpected(args);
    }

    return {
        ...makeProgrammingExpected({
            language: args.language,
            checkMode: args.checkMode,
            stdin: args.stdin,
            stdout: args.stdout,
            match: args.match,
            tests: args.tests,
            semanticChecks: args.semanticChecks,
            workspaceExpectations: args.workspaceExpectations,
            solutionCode: args.solutionCode,
        }),
        ...(Array.isArray(args.sourceChecks) && args.sourceChecks.length
            ? { sourceChecks: args.sourceChecks }
            : {}),
    } as CodeExpectedInput;
}

export { toProgrammingCodeTests, toSqlCodeTests };

export function normalizeCodeExpectedForSave(
    expected: any,
): ProgrammingCodeExpected | SqlCodeExpected {

    const terminalWorkspaceShellTask =
        normalizeTerminalWorkspaceShellTaskExpectedForSave(expected);

    if (terminalWorkspaceShellTask) {
        return terminalWorkspaceShellTask as any;
    }


    const language =
        typeof expected?.language === "string" ? expected.language : "python";
    const solutionFiles = expected?.solutionFiles;
    const sourceChecks = Array.isArray(expected?.sourceChecks)
        ? expected.sourceChecks.filter(Boolean)
        : [];
    const shellTaskMeta = getShellTaskExpectedMeta(expected);
    if (language === "sql") {
        const normalized = makeSqlExpected(expected);
        const canonTests = normalized.tests.slice(0, 12);

        if (!canonTests.length) {
            throw new Error(
                `Generator bug: SQL code_input expected is missing tests. expected=${JSON.stringify(
                    expected,
                    null,
                    2,
                )}`,
            );
        }

        const needsSolution = canonTests.some((test) => test.compareTo === "solution");
        const solutionCode =
            typeof expected?.solutionCode === "string" ? expected.solutionCode : undefined;

        if (needsSolution && !solutionCode?.trim()) {
            throw new Error(
                `Generator bug: SQL code_input expected is missing solutionCode. expected=${JSON.stringify(
                    expected,
                    null,
                    2,
                )}`,
            );
        }

        const persisted = {
            ...normalized,
            tests: canonTests,
            solutionCode,
            ...(solutionFiles !== undefined ? { solutionFiles } : {}),
            ...(sourceChecks.length ? { sourceChecks } : {}),
        };
        const parsed = parseCodeExpected(persisted);

        if (!parsed.success) {
            throw new Error(
                `Generator bug: invalid code_input expected payload. expected=${JSON.stringify(
                    expected,
                    null,
                    2,
                )} parsedError=${JSON.stringify(parsed.error.format(), null, 2)}`,
            );
        }

        return {
            ...parsed.data,
            ...(solutionFiles !== undefined ? { solutionFiles } : {}),
            ...(sourceChecks.length ? { sourceChecks } : {}),
        } as SqlCodeExpected;
    }

    const normalized = makeProgrammingExpected(expected);

    if (normalized.checkMode === "semantic") {
        if (!normalized.semanticChecks.length) {
            throw new Error(
                `Generator bug: semantic code_input expected is missing semanticChecks. expected=${JSON.stringify(
                    expected,
                    null,
                    2,
                )}`,
            );
        }

        const persisted = {
            ...normalized,
            ...(solutionFiles !== undefined ? { solutionFiles } : {}),
            ...(sourceChecks.length ? { sourceChecks } : {}),
        };
        const parsed = parseCodeExpected(persisted);

        if (!parsed.success) {
            throw new Error(
                `Generator bug: invalid semantic code_input expected payload. expected=${JSON.stringify(
                    expected,
                    null,
                    2,
                )} parsedError=${JSON.stringify(parsed.error.format(), null, 2)}`,
            );
        }

        return {
            ...parsed.data,
            ...(solutionFiles !== undefined ? { solutionFiles } : {}),
            ...(sourceChecks.length ? { sourceChecks } : {}),
        } as ProgrammingCodeExpected;
    }

    const canonTests = normalized.tests.slice(0, 12);

    if (!canonTests.length) {
        throw new Error(
            `Generator bug: code_input expected is missing tests/stdout. expected=${JSON.stringify(
                expected,
                null,
                2,
            )}`,
        );
    }

    const persisted = {
        ...normalized,
        tests: canonTests,
        ...shellTaskMeta,
        ...(solutionFiles !== undefined ? { solutionFiles } : {}),
        ...(sourceChecks.length ? { sourceChecks } : {}),
    };
    const parsed = parseCodeExpected(persisted);

    if (!parsed.success) {
        throw new Error(
            `Generator bug: invalid stdout code_input expected payload. expected=${JSON.stringify(
                expected,
                null,
                2,
            )} parsedError=${JSON.stringify(parsed.error.format(), null, 2)}`,
        );
    }

    return {
        ...parsed.data,
        ...shellTaskMeta,
        ...(solutionFiles !== undefined ? { solutionFiles } : {}),
        ...(sourceChecks.length ? { sourceChecks } : {}),
    } as ProgrammingCodeExpected;
}

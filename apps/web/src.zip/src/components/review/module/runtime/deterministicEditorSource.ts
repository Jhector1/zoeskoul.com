import type { WorkspaceStateV2 } from "@/components/ide/types";
import type { ReviewTargetEntry } from "./reviewTargetRegistry";

export type ReviewDeterministicEditorSource = {
  ownerKey: string;
  ownerKind: "card" | "exercise";
  targetKey: string;
  toolScopeKey: string;
  language: string;
  manifest: any;
  entry: ReviewTargetEntry;
  workspaceSeedMode: "starter" | "empty";
};

function manifestHasStarter(manifest: any, entry: ReviewTargetEntry) {
  const item = entry?.item ?? manifest;
  const source = item?.spec ?? item ?? {};
  const workspaceContainer = source?.workspace ?? manifest?.workspace ?? {};
  const workspaceCandidate =
    entry.starterWorkspace ??
    workspaceContainer ??
    source?.initialWorkspace ??
    source?.starterWorkspace ??
    manifest?.initialWorkspace ??
    manifest?.starterWorkspace ??
    null;

  const isWorkspace =
    !!workspaceCandidate &&
    typeof workspaceCandidate === "object" &&
    (workspaceCandidate as WorkspaceStateV2).version === 2 &&
    Array.isArray((workspaceCandidate as WorkspaceStateV2).nodes);

  return Boolean(
    isWorkspace ||
      (Array.isArray(entry.starterFiles) && entry.starterFiles.length > 0) ||
      (typeof entry.starterCode === "string" && entry.starterCode.length > 0) ||
      (Array.isArray(workspaceContainer?.starterFiles) && workspaceContainer.starterFiles.length > 0) ||
      (Array.isArray(workspaceContainer?.solutionFiles) && workspaceContainer.solutionFiles.length > 0) ||
      (Array.isArray(workspaceContainer?.files) && workspaceContainer.files.length > 0) ||
      (Array.isArray(workspaceContainer?.initialFiles) && workspaceContainer.initialFiles.length > 0) ||
      (Array.isArray(workspaceContainer?.workspaceFiles) && workspaceContainer.workspaceFiles.length > 0) ||
      (typeof workspaceContainer?.solutionCode === "string" && workspaceContainer.solutionCode.trim().length > 0) ||
      (Array.isArray(source?.starterFiles) && source.starterFiles.length > 0) ||
      (Array.isArray(source?.solutionFiles) && source.solutionFiles.length > 0) ||
      (Array.isArray(source?.files) && source.files.length > 0) ||
      (typeof workspaceContainer?.starterCode === "string" && workspaceContainer.starterCode.trim().length > 0) ||
      (typeof workspaceContainer?.code === "string" && workspaceContainer.code.trim().length > 0) ||
      (typeof workspaceContainer?.content === "string" && workspaceContainer.content.trim().length > 0) ||
      (typeof workspaceContainer?.source === "string" && workspaceContainer.source.trim().length > 0) ||
      (typeof source?.solutionCode === "string" && source.solutionCode.trim().length > 0) ||
      (typeof source?.starterCode === "string" && source.starterCode.trim().length > 0) ||
      (typeof source?.code === "string" && source.code.trim().length > 0) ||
      (typeof source?.content === "string" && source.content.trim().length > 0) ||
      (typeof source?.source === "string" && source.source.trim().length > 0) ||
      (Array.isArray(source?.recipe?.solutionFiles) && source.recipe.solutionFiles.length > 0) ||
      (typeof source?.recipe?.solutionCode === "string" && source.recipe.solutionCode.trim().length > 0) ||
      (Array.isArray(source?.recipe?.starterFiles) && source.recipe.starterFiles.length > 0) ||
      (typeof source?.recipe?.starterCode === "string" && source.recipe.starterCode.trim().length > 0) ||
      (typeof source?.recipe?.solutionTemplate === "string" && source.recipe.solutionTemplate.trim().length > 0)
  );
}

export function resolveDeterministicEditorSource(
  entry: ReviewTargetEntry | null | undefined,
): ReviewDeterministicEditorSource | null {
  if (!entry) return null;

  const manifest = entry.toolManifest ?? entry.item ?? null;
  return {
    ownerKey: entry.ownerKey,
    ownerKind: entry.ownerKind,
    targetKey: entry.targetKey,
    toolScopeKey: entry.toolScopeKey,
    language: entry.language ?? "python",
    manifest,
    entry,
    workspaceSeedMode: manifestHasStarter(manifest, entry) ? "starter" : "empty",
  };
}

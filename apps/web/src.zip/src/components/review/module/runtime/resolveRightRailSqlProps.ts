import {
    STUDENTS_INITIAL_TABLE_SNAPSHOTS,
    STUDENTS_SQL_SCHEMA,
    STUDENTS_SQL_SEED,
} from "../data/studentsSqlFallback";

type SqlResultShape = "table";

export type RightRailSqlToolState = {
    toolLang?: string | null;
    toolSqlDialect?: string | null;
    toolSqlDatasetId?: string | null;
    toolSqlSchemaSql?: string | null;
    toolSqlSeedSql?: string | null;
    toolSqlInitialTableSnapshots?: unknown;
};

export type RightRailSqlFallback = {
    sqlDialect?: string | null;
    sqlDatasetId?: string | null;
    sqlSchemaSql?: string | null;
    sqlSeedSql?: string | null;
    sqlInitialTableSnapshots?: unknown;
};

export type ResolveRightRailSqlPropsArgs = {
    routeCanUseBoundExercise: boolean;
    tool: RightRailSqlToolState;
    topicSqlFallback?: RightRailSqlFallback | null;
};

function firstNonBlank(...values: Array<string | null | undefined>) {
    for (const value of values) {
        if (typeof value === "string" && value.trim()) return value;
    }

    return undefined;
}

export function resolveRightRailSqlProps({
                                             routeCanUseBoundExercise,
                                             tool,
                                             topicSqlFallback,
                                         }: ResolveRightRailSqlPropsArgs): {
    toolSqlDialect?: string;
    sqlResultShape?: SqlResultShape;
    sqlDatasetId?: string;
    sqlSchemaSql?: string;
    sqlSeedSql?: string;
    sqlInitialTableSnapshots?: unknown;
} {
    const hasExerciseSqlDataset = routeCanUseBoundExercise && Boolean(tool.toolSqlDatasetId);
    const hasSqlFallbackDataset = Boolean(topicSqlFallback?.sqlDatasetId);
    const isSqlTool = tool.toolLang === "sql" || hasExerciseSqlDataset || hasSqlFallbackDataset;

    return {
        toolSqlDialect: firstNonBlank(
            hasExerciseSqlDataset ? tool.toolSqlDialect : undefined,
            topicSqlFallback?.sqlDialect,
            tool.toolSqlDialect,
        ),

        sqlResultShape: isSqlTool ? "table" : undefined,

        sqlDatasetId: firstNonBlank(
            routeCanUseBoundExercise ? tool.toolSqlDatasetId : undefined,
            topicSqlFallback?.sqlDatasetId,
        ),

        sqlSchemaSql: firstNonBlank(
            routeCanUseBoundExercise ? tool.toolSqlSchemaSql : undefined,
            topicSqlFallback?.sqlSchemaSql,
            tool.toolLang === "sql" ? undefined : STUDENTS_SQL_SCHEMA,
        ),

        sqlSeedSql: firstNonBlank(
            routeCanUseBoundExercise ? tool.toolSqlSeedSql : undefined,
            topicSqlFallback?.sqlSeedSql,
            tool.toolLang === "sql" ? undefined : STUDENTS_SQL_SEED,
        ),

        sqlInitialTableSnapshots:
            (routeCanUseBoundExercise ? tool.toolSqlInitialTableSnapshots : undefined) ??
            topicSqlFallback?.sqlInitialTableSnapshots ??
            (tool.toolLang === "sql" ? undefined : STUDENTS_INITIAL_TABLE_SNAPSHOTS),
    };
}
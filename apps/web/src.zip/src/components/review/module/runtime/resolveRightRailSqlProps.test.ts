import { describe, expect, it } from "vitest";

import {
    STUDENTS_INITIAL_TABLE_SNAPSHOTS,
    STUDENTS_SQL_SCHEMA,
    STUDENTS_SQL_SEED,
} from "../data/studentsSqlFallback";

import { resolveRightRailSqlProps } from "./resolveRightRailSqlProps";

describe("resolveRightRailSqlProps", () => {
    it("keeps module/topic SQL fallback available when the route is not exercise-bound", () => {
        const snapshots = {
            products: {
                columns: ["id", "name", "category"],
                rows: [
                    { id: 1, name: "Sketchbook", category: "Art" },
                ],
            },
        };

        const props = resolveRightRailSqlProps({
            routeCanUseBoundExercise: false,
            tool: {
                toolLang: "sql",
                toolSqlDialect: "sqlite",
                toolSqlDatasetId: null,
                toolSqlSchemaSql: null,
                toolSqlSeedSql: null,
                toolSqlInitialTableSnapshots: undefined,
            },
            topicSqlFallback: {
                sqlDialect: "sqlite",
                sqlDatasetId: "products_catalog",
                sqlSchemaSql: "CREATE TABLE products (id INTEGER, name TEXT, category TEXT);",
                sqlSeedSql: "INSERT INTO products VALUES (1, 'Sketchbook', 'Art');",
                sqlInitialTableSnapshots: snapshots,
            },
        });

        expect(props).toEqual({
            toolSqlDialect: "sqlite",
            sqlResultShape: "table",
            sqlDatasetId: "products_catalog",
            sqlSchemaSql: "CREATE TABLE products (id INTEGER, name TEXT, category TEXT);",
            sqlSeedSql: "INSERT INTO products VALUES (1, 'Sketchbook', 'Art');",
            sqlInitialTableSnapshots: snapshots,
        });
    });

    it("lets an exercise-bound SQL dataset override topic/module fallback", () => {
        const fallbackSnapshots = {
            products: {
                columns: ["id"],
                rows: [{ id: 1 }],
            },
        };

        const exerciseSnapshots = {
            orders: {
                columns: ["id", "total"],
                rows: [{ id: 10, total: 25 }],
            },
        };

        const props = resolveRightRailSqlProps({
            routeCanUseBoundExercise: true,
            tool: {
                toolLang: "sql",
                toolSqlDialect: "sqlite",
                toolSqlDatasetId: "exercise_orders",
                toolSqlSchemaSql: "CREATE TABLE orders (id INTEGER, total INTEGER);",
                toolSqlSeedSql: "INSERT INTO orders VALUES (10, 25);",
                toolSqlInitialTableSnapshots: exerciseSnapshots,
            },
            topicSqlFallback: {
                sqlDialect: "sqlite",
                sqlDatasetId: "products_catalog",
                sqlSchemaSql: "CREATE TABLE products (id INTEGER);",
                sqlSeedSql: "INSERT INTO products VALUES (1);",
                sqlInitialTableSnapshots: fallbackSnapshots,
            },
        });

        expect(props).toEqual({
            toolSqlDialect: "sqlite",
            sqlResultShape: "table",
            sqlDatasetId: "exercise_orders",
            sqlSchemaSql: "CREATE TABLE orders (id INTEGER, total INTEGER);",
            sqlSeedSql: "INSERT INTO orders VALUES (10, 25);",
            sqlInitialTableSnapshots: exerciseSnapshots,
        });
    });

    it("falls back to topic/module SQL when exercise route exists but exercise SQL fields are blank", () => {
        const snapshots = {
            products: {
                columns: ["id", "category"],
                rows: [{ id: 4, category: "Art" }],
            },
        };

        const props = resolveRightRailSqlProps({
            routeCanUseBoundExercise: true,
            tool: {
                toolLang: "sql",
                toolSqlDialect: "",
                toolSqlDatasetId: "",
                toolSqlSchemaSql: "   ",
                toolSqlSeedSql: "",
                toolSqlInitialTableSnapshots: undefined,
            },
            topicSqlFallback: {
                sqlDialect: "sqlite",
                sqlDatasetId: "products_catalog",
                sqlSchemaSql: "CREATE TABLE products (id INTEGER, category TEXT);",
                sqlSeedSql: "INSERT INTO products VALUES (4, 'Art');",
                sqlInitialTableSnapshots: snapshots,
            },
        });

        expect(props.toolSqlDialect).toBe("sqlite");
        expect(props.sqlResultShape).toBe("table");
        expect(props.sqlDatasetId).toBe("products_catalog");
        expect(props.sqlSchemaSql).toBe("CREATE TABLE products (id INTEGER, category TEXT);");
        expect(props.sqlSeedSql).toBe("INSERT INTO products VALUES (4, 'Art');");
        expect(props.sqlInitialTableSnapshots).toBe(snapshots);
    });

    it("does not expose fallback SQL dataset when neither tool nor runtime has SQL", () => {
        const props = resolveRightRailSqlProps({
            routeCanUseBoundExercise: false,
            tool: {
                toolLang: "python",
                toolSqlDialect: undefined,
                toolSqlDatasetId: undefined,
                toolSqlSchemaSql: undefined,
                toolSqlSeedSql: undefined,
                toolSqlInitialTableSnapshots: undefined,
            },
            topicSqlFallback: null,
        });

        expect(props.toolSqlDialect).toBeUndefined();
        expect(props.sqlResultShape).toBeUndefined();
        expect(props.sqlDatasetId).toBeUndefined();

        // Existing non-SQL generic fallback behavior stays preserved.
        expect(props.sqlSchemaSql).toBe(STUDENTS_SQL_SCHEMA);
        expect(props.sqlSeedSql).toBe(STUDENTS_SQL_SEED);
        expect(props.sqlInitialTableSnapshots).toBe(STUDENTS_INITIAL_TABLE_SNAPSHOTS);
    });

    it("does not inject students fallback schema/seed over a plain SQL editor with no dataset", () => {
        const props = resolveRightRailSqlProps({
            routeCanUseBoundExercise: false,
            tool: {
                toolLang: "sql",
                toolSqlDialect: "sqlite",
                toolSqlDatasetId: undefined,
                toolSqlSchemaSql: undefined,
                toolSqlSeedSql: undefined,
                toolSqlInitialTableSnapshots: undefined,
            },
            topicSqlFallback: null,
        });

        expect(props.toolSqlDialect).toBe("sqlite");
        expect(props.sqlResultShape).toBe("table");
        expect(props.sqlDatasetId).toBeUndefined();
        expect(props.sqlSchemaSql).toBeUndefined();
        expect(props.sqlSeedSql).toBeUndefined();
        expect(props.sqlInitialTableSnapshots).toBeUndefined();
    });


        it("prefers exercise-bound SQL props over runtime fallback props", () => {
            const fallbackSnapshots = {
                products: {
                    columns: ["id", "name"],
                    rows: [{ id: 1, name: "Sketchbook" }],
                },
            };

            const exerciseSnapshots = {
                orders: {
                    columns: ["id", "total"],
                    rows: [{ id: 10, total: 25 }],
                },
            };

            const props = resolveRightRailSqlProps({
                routeCanUseBoundExercise: true,
                tool: {
                    toolLang: "sql",
                    toolSqlDialect: "sqlite",
                    toolSqlDatasetId: "exercise_orders",
                    toolSqlSchemaSql: "CREATE TABLE orders (id INTEGER, total INTEGER);",
                    toolSqlSeedSql: "INSERT INTO orders VALUES (10, 25);",
                    toolSqlInitialTableSnapshots: exerciseSnapshots,
                },
                topicSqlFallback: {
                    sqlDialect: "sqlite",
                    sqlDatasetId: "products_catalog",
                    sqlSchemaSql: "CREATE TABLE products (id INTEGER, name TEXT);",
                    sqlSeedSql: "INSERT INTO products VALUES (1, 'Sketchbook');",
                    sqlInitialTableSnapshots: fallbackSnapshots,
                },
            });

            expect(props.toolSqlDialect).toBe("sqlite");
            expect(props.sqlResultShape).toBe("table");
            expect(props.sqlDatasetId).toBe("exercise_orders");
            expect(props.sqlSchemaSql).toBe("CREATE TABLE orders (id INTEGER, total INTEGER);");
            expect(props.sqlSeedSql).toBe("INSERT INTO orders VALUES (10, 25);");
            expect(props.sqlInitialTableSnapshots).toBe(exerciseSnapshots);
        });



        it("falls back to runtime SQL defaults when exercise-bound SQL fields are blank", () => {
            const fallbackSnapshots = {
                products: {
                    columns: ["id", "name", "category"],
                    rows: [{ id: 1, name: "Sketchbook", category: "Art" }],
                },
            };

            const props = resolveRightRailSqlProps({
                routeCanUseBoundExercise: true,
                tool: {
                    toolLang: "sql",
                    toolSqlDialect: "",
                    toolSqlDatasetId: "",
                    toolSqlSchemaSql: "   ",
                    toolSqlSeedSql: "",
                    toolSqlInitialTableSnapshots: undefined,
                },
                topicSqlFallback: {
                    sqlDialect: "sqlite",
                    sqlDatasetId: "products_catalog",
                    sqlSchemaSql: "CREATE TABLE products (id INTEGER, name TEXT, category TEXT);",
                    sqlSeedSql: "INSERT INTO products VALUES (1, 'Sketchbook', 'Art');",
                    sqlInitialTableSnapshots: fallbackSnapshots,
                },
            });

            expect(props.toolSqlDialect).toBe("sqlite");
            expect(props.sqlResultShape).toBe("table");
            expect(props.sqlDatasetId).toBe("products_catalog");
            expect(props.sqlSchemaSql).toBe("CREATE TABLE products (id INTEGER, name TEXT, category TEXT);");
            expect(props.sqlSeedSql).toBe("INSERT INTO products VALUES (1, 'Sketchbook', 'Art');");
            expect(props.sqlInitialTableSnapshots).toBe(fallbackSnapshots);
        });


}




);
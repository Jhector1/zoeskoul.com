import type { ReviewCard, ReviewModule } from "@/lib/subjects/types";
import { getCardStateKey, getExerciseStateKey } from "./exerciseKeys";

export type ReviewTargetKind = "sketch" | "exercise" | "quiz" | "card" | "project" | "text" | "video";

export type ReviewTargetEntry = {
  targetKey: string;
  routeKey: string;
  targetKind: ReviewTargetKind;
  sectionSlug: string;
  topicId: string;
  topicSlug: string;
  cardId: string;
  cardType: ReviewCard["type"];
  targetSlug: string;
  ownerKind: "card" | "exercise";
  ownerKey: string;
  cardKey: string;
  toolScopeKey: string;
  exerciseId?: string;
  exerciseStateKey?: string;
  language?: string;
  starterFiles?: Array<{ path: string; content: string; language?: string; entry?: boolean }>;
  solutionFiles?: Array<{ path: string; content: string; language?: string; entry?: boolean }>;
  starterCode?: string;
  solutionCode?: string;
  starterWorkspace?: any;
  toolManifest?: any;
  item: any;
};

export type ReviewTargetRegistry = {
  byKey: Record<string, ReviewTargetEntry>;
  orderedKeys: string[];
  byRoute: Record<string, string>;
};

function cleanSegment(value: unknown, fallback = "item") {
  const raw = typeof value === "string" ? value.trim() : "";
  if (!raw) return fallback;
  return (
    raw
      .replace(/\./g, "-")
      .replace(/_/g, "-")
      .replace(/[^a-zA-Z0-9-]+/g, "-")
      .replace(/-+/g, "-")
      .replace(/^-|-$/g, "")
      .toLowerCase() || fallback
  );
}

function lastIdSegment(value: unknown) {
  const raw = typeof value === "string" ? value.trim() : "";
  if (!raw) return "";
  const parts = raw.split(/[.:/]/).filter(Boolean);
  return parts[parts.length - 1] ?? raw;
}

function getTopicRouteSlug(topicId: string) {
  return cleanSegment(topicId, "topic");
}

function getCardTargetKind(card: ReviewCard): ReviewTargetKind {
  switch (card.type) {
    case "sketch":
    case "quiz":
    case "project":
    case "text":
    case "video":
      return card.type;
    default:
      return "card";
  }
}

function getCardTargetSlug(card: ReviewCard) {
  if (card.type === "sketch") {
    return cleanSegment(lastIdSegment(card.sketchId), cleanSegment(card.id, "sketch"));
  }
  return cleanSegment(card.id, "card");
}


function registryLooksLikePythonStarterCode(value: string) {
  const s = String(value ?? "").trim();
  if (!s || s.length > 5000) return false;

  return (
    /\bprint\s*\(/.test(s) ||
    /\binput\s*\(/.test(s) ||
    /\bint\s*\(/.test(s) ||
    /\bfloat\s*\(/.test(s) ||
    /\bstr\s*\(/.test(s) ||
    /\bdef\s+[a-zA-Z_][a-zA-Z0-9_]*\s*\(/.test(s) ||
    /^\s*[a-zA-Z_][a-zA-Z0-9_]*\s*=/.test(s) ||
    /#\s*TODO/i.test(s)
  );
}

function extractRegistryCodeFence(value: string) {
  const source = String(value ?? "");

  const preferred = source.match(/```(?:python|py)\s*([\s\S]*?)```/i);
  if (preferred?.[1]?.trim()) return preferred[1].trim();

  const generic = source.match(/```\s*([\s\S]*?)```/);
  if (generic?.[1]?.trim() && registryLooksLikePythonStarterCode(generic[1])) {
    return generic[1].trim();
  }

  return "";
}

function extractRegistryStarterCodeFromLooseContent(input: unknown, seen = new WeakSet<object>()): string {
  if (input == null) return "";

  if (typeof input === "string") {
    const fenced = extractRegistryCodeFence(input);
    if (fenced) return fenced;
    return registryLooksLikePythonStarterCode(input) ? input.trim() : "";
  }

  if (typeof input !== "object") return "";

  if (seen.has(input as object)) return "";
  seen.add(input as object);

  if (Array.isArray(input)) {
    for (const item of input) {
      const found = extractRegistryStarterCodeFromLooseContent(item, seen);
      if (found) return found;
    }
    return "";
  }

  const obj = input as Record<string, unknown>;

  const preferredKeys = [
    "starterCode",
    "solutionCode",
    "solutionTemplate",
    "code",
    "content",
    "source",
    "body",
    "markdown",
    "md",
    "text",
    "prompt",
    "instructions",
    "description",
    "example",
    "examples",
    "steps",
    "cards",
    "blocks",
    "children",
    "items",
    "recipe",
    "workspace",
    "spec"
  ];

  for (const key of preferredKeys) {
    if (key in obj) {
      const found = extractRegistryStarterCodeFromLooseContent(obj[key], seen);
      if (found) return found;
    }
  }

  for (const [key, value] of Object.entries(obj)) {
    if (preferredKeys.includes(key)) continue;
    const found = extractRegistryStarterCodeFromLooseContent(value, seen);
    if (found) return found;
  }

  return "";
}


function pickStarterFiles(
  item: any,
  options: { includeSolutionFiles?: boolean } = {},
) {
  const source = item?.spec ?? item;
  const includeSolutionFiles = options.includeSolutionFiles === true;

  return (
    source?.workspace?.starterFiles ??
    source?.workspace?.files ??
    source?.workspace?.initialFiles ??
    source?.workspace?.workspaceFiles ??
    source?.starterFiles ??
    source?.files ??
    source?.initialFiles ??
    source?.workspaceFiles ??
    source?.recipe?.starterFiles ??
    source?.recipe?.files ??
    source?.recipe?.initialFiles ??
    (includeSolutionFiles ? source?.workspace?.solutionFiles : undefined) ??
    (includeSolutionFiles ? source?.solutionFiles : undefined) ??
    (includeSolutionFiles ? source?.recipe?.solutionFiles : undefined) ??
    undefined
  );
}

function pickSolutionFiles(item: any) {
  const source = item?.spec ?? item;
  return (
    source?.workspace?.solutionFiles ??
    source?.solutionFiles ??
    source?.recipe?.solutionFiles ??
    undefined
  );
}

function pickStarterCode(
  item: any,
  options: { includeSolutionCode?: boolean; allowLooseExtraction?: boolean } = {},
) {
  const source = item?.spec ?? item;
  const includeSolutionCode = options.includeSolutionCode === true;

  const starterExplicit =
    source?.workspace?.starterCode ??
    source?.workspace?.code ??
    source?.workspace?.content ??
    source?.workspace?.source ??
    source?.starterCode ??
    source?.code ??
    source?.content ??
    source?.source ??
    source?.recipe?.starterCode ??
    "";

  const starterExplicitString = String(starterExplicit ?? "").trim();
  if (starterExplicitString) return starterExplicitString;

  if (includeSolutionCode) {
    const solutionExplicit =
      source?.workspace?.solutionCode ??
      source?.solutionCode ??
      source?.recipe?.solutionCode ??
      source?.recipe?.solutionTemplate ??
      source?.solutionTemplate ??
      "";

    const solutionExplicitString = String(solutionExplicit ?? "").trim();
    if (solutionExplicitString) return solutionExplicitString;
  }

  // Important: scan the full item, not only item.spec.
  // Some lesson/project/sketch code examples live on card.content/body/blocks,
  // while spec only has runtime/workspace metadata. Do not do this for SQL,
  // where prose and solution SQL must not become starter files implicitly.
  return options.allowLooseExtraction === false
    ? undefined
    : extractRegistryStarterCodeFromLooseContent(item) || undefined;
}

function defaultLanguageForSubject(subjectSlug: string) {
  switch (subjectSlug) {
    case "sql":
      return "sql";
    case "java":
      return "java";
    case "javascript":
      return "javascript";
    case "c":
      return "c";
    case "cpp":
      return "cpp";
    case "python":
    case "python-for-beginners":
    default:
      return "python";
  }
}

function inferRuntimeDefaultLanguage(runtimeDefaults: any, subjectSlug: string) {
  const explicit = String(runtimeDefaults?.language ?? runtimeDefaults?.lang ?? "").trim();
  if (explicit) return explicit;

  if (String(runtimeDefaults?.kind ?? "").toLowerCase() === "sql") {
    return "sql";
  }

  return defaultLanguageForSubject(subjectSlug);
}

function pickLanguage(item: any, fallbackLanguage: string) {
  const source = item?.spec ?? item;
  return (
    source?.language ??
    source?.lang ??
    source?.workspace?.language ??
    source?.recipe?.language ??
    fallbackLanguage
  );
}

function buildRouteKey(args: {
  sectionSlug: string;
  topicSlug: string;
  targetKind: string;
  targetSlug: string;
}) {
  return `${args.sectionSlug}/${args.topicSlug}/${args.targetKind}/${args.targetSlug}`;
}

function buildToolManifest(card: ReviewCard) {
  if (card.type === "sketch") {
    return {
      ...(card.spec ?? {}),
      runtime: (card.spec as any)?.runtime ?? null,
      workspace: (card.spec as any)?.workspace ?? null,
    };
  }

  if (card.type === "project" || card.type === "quiz") {
    return {
      ...(card.spec ?? {}),
      runtime: (card.spec as any)?.runtime ?? null,
      workspace: (card.spec as any)?.workspace ?? null,
    };
  }

  return {
    ...(card as any)?.spec,
    workspace: (card as any)?.spec?.workspace ?? null,
  };
}

function getProjectExerciseEntries(card: Extract<ReviewCard, { type: "project" }>) {
  const steps = Array.isArray(card.spec?.steps) ? card.spec.steps : [];
  return steps
    .map((step: any) => {
      const exerciseId =
        typeof step?.exerciseKey === "string" && step.exerciseKey.trim()
          ? step.exerciseKey.trim()
          : typeof step?.id === "string" && step.id.trim()
            ? step.id.trim()
            : "";

      return {
        step,
        exerciseId,
        routeSlug: cleanSegment(
          typeof step?.id === "string" && step.id.trim() ? step.id : exerciseId,
          "exercise",
        ),
      };
    })
    .filter((entry) => entry.exerciseId);
}

export function buildReviewTargetRegistry(args: {
  mod: ReviewModule;
  subjectSlug: string;
  moduleSlug: string;
}): ReviewTargetRegistry {
  const { mod, subjectSlug, moduleSlug } = args;
  const byKey: Record<string, ReviewTargetEntry> = {};
  const orderedKeys: string[] = [];
  const byRoute: Record<string, string> = {};

  const sections = Array.isArray(mod.sections) ? mod.sections : [];

  for (const section of sections) {
    const sectionSlug = section.slug;
    const topics = Array.isArray(section.topics) ? section.topics : [];

    for (const topic of topics) {
      const topicId = topic.id;
      const topicSlug = getTopicRouteSlug(topicId);
      const rawManifest = (topic.meta as any)?.rawManifest ?? null;
      const topicRuntimeDefaults =
        (topic as any)?.meta?.runtimeDefaults ??
        (mod as any)?.runtimeDefaults ??
        (mod as any)?.meta?.runtimeDefaults ??
        null;
      const topicFallbackLanguage = inferRuntimeDefaultLanguage(
        topicRuntimeDefaults,
        subjectSlug,
      );
      const rawSketches = Array.isArray(rawManifest?.sketches) ? rawManifest.sketches : [];
      const rawExercises = Array.isArray(rawManifest?.exercises) ? rawManifest.exercises : [];
      const cards = Array.isArray(topic.cards) ? topic.cards : [];

      for (const card of cards) {
        const rawSketch =
          card.type === "sketch"
            ? rawSketches.find((sketch: any) => sketch?.id === lastIdSegment((card as any).sketchId))
            : null;
        const cardKey = getCardStateKey({
          subjectSlug,
          moduleSlug,
          sectionSlug,
          topicId,
          cardId: card.id,
        });
        const cardTargetKind = getCardTargetKind(card);
        const cardTargetSlug = getCardTargetSlug(card);
        const cardRouteKey = buildRouteKey({
          sectionSlug,
          topicSlug,
          targetKind: cardTargetKind,
          targetSlug: cardTargetSlug,
        });
        const cardLanguage = pickLanguage(rawSketch ?? card, topicFallbackLanguage);
        const cardUsesSql = String(cardLanguage).toLowerCase() === "sql";
        const cardEntry: ReviewTargetEntry = {
          targetKey: `card:${cardKey}`,
          routeKey: cardRouteKey,
          targetKind: cardTargetKind,
          sectionSlug,
          topicId,
          topicSlug,
          cardId: card.id,
          cardType: card.type,
          targetSlug: cardTargetSlug,
          ownerKind: "card",
          ownerKey: cardKey,
          cardKey,
          toolScopeKey: `${cardKey}:general`,
          language: cardLanguage,
          starterFiles: pickStarterFiles(rawSketch ?? card, { includeSolutionFiles: !cardUsesSql }),
          solutionFiles: pickSolutionFiles(rawSketch ?? card),
          starterCode: pickStarterCode(rawSketch ?? card, {
            includeSolutionCode: !cardUsesSql,
            allowLooseExtraction: !cardUsesSql,
          }),
          solutionCode: pickStarterCode(rawSketch ?? card, {
            includeSolutionCode: true,
            allowLooseExtraction: !cardUsesSql,
          }),
          starterWorkspace: rawSketch?.workspace ?? (card.spec as any)?.workspace ?? null,
          toolManifest: rawSketch
            ? {
                ...rawSketch,
                runtime: rawSketch.runtime ?? (card.spec as any)?.runtime ?? null,
                workspace: rawSketch.workspace ?? (card.spec as any)?.workspace ?? null,
              }
            : buildToolManifest(card),
          item: rawSketch ?? card,
        };

        byKey[cardEntry.targetKey] = cardEntry;
        byRoute[cardRouteKey] = cardEntry.targetKey;
        orderedKeys.push(cardEntry.targetKey);

        if (card.type !== "project") continue;

        for (const exercise of getProjectExerciseEntries(card)) {
          const rawExercise =
            rawExercises.find((item: any) => item?.id === exercise.exerciseId) ??
            rawExercises.find((item: any) => item?.id === exercise.step?.id) ??
            null;
          const exerciseStateKey = getExerciseStateKey(
            {
              subjectSlug,
              moduleSlug,
              sectionSlug,
              topicId,
              cardId: card.id,
            },
            exercise.exerciseId,
          );
          const exerciseRouteKey = buildRouteKey({
            sectionSlug,
            topicSlug,
            targetKind: "exercise",
            targetSlug: exercise.routeSlug,
          });
          const exerciseLanguage = pickLanguage(rawExercise ?? exercise.step, topicFallbackLanguage);
          const exerciseUsesSql = String(exerciseLanguage).toLowerCase() === "sql";
          const exerciseEntry: ReviewTargetEntry = {
            targetKey: `exercise:${exerciseStateKey}`,
            routeKey: exerciseRouteKey,
            targetKind: "exercise",
            sectionSlug,
            topicId,
            topicSlug,
            cardId: card.id,
            cardType: card.type,
            targetSlug: exercise.routeSlug,
            ownerKind: "exercise",
            ownerKey: exerciseStateKey,
            cardKey,
            toolScopeKey: exerciseStateKey,
            exerciseId: exercise.exerciseId,
            exerciseStateKey,
            language: exerciseLanguage,
            starterFiles: pickStarterFiles(rawExercise ?? exercise.step, { includeSolutionFiles: !exerciseUsesSql }),
            solutionFiles: pickSolutionFiles(rawExercise ?? exercise.step),
            starterCode: pickStarterCode(rawExercise ?? exercise.step, {
              includeSolutionCode: !exerciseUsesSql,
              allowLooseExtraction: !exerciseUsesSql,
            }),
            solutionCode: pickStarterCode(rawExercise ?? exercise.step, {
              includeSolutionCode: true,
              allowLooseExtraction: !exerciseUsesSql,
            }),
            starterWorkspace: rawExercise?.workspace ?? exercise.step?.workspace ?? null,
            toolManifest: rawExercise ?? exercise.step ?? null,
            item: rawExercise ?? exercise.step,
          };

          byKey[exerciseEntry.targetKey] = exerciseEntry;
          byRoute[exerciseRouteKey] = exerciseEntry.targetKey;
          orderedKeys.push(exerciseEntry.targetKey);
        }
      }
    }
  }

  return { byKey, orderedKeys, byRoute };
}

export function getReviewTargetEntryByRoute(
  registry: ReviewTargetRegistry | null | undefined,
  route: {
    sectionSlug?: string | null;
    topicSlug?: string | null;
    targetKind?: string | null;
    targetSlug?: string | null;
  },
) {
  if (!registry) return null;
  const { sectionSlug, topicSlug, targetKind, targetSlug } = route;
  if (!sectionSlug || !topicSlug || !targetKind || !targetSlug) return null;
  const routeKey = buildRouteKey({ sectionSlug, topicSlug, targetKind, targetSlug });
  const targetKey = registry.byRoute[routeKey];
  return targetKey ? registry.byKey[targetKey] ?? null : null;
}

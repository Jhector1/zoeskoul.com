
export { default } from "./ReviewModulePage";

"use client";

import { useEffect, useMemo, useRef, useState, useCallback } from "react";
import type { ReviewProgressState, ReviewTopicProgress } from "@/lib/review/progressTypes";
import {
    emptyReviewProgress,
    fetchReviewProgressGET,
    buildReviewProgressPayload,
} from "@/lib/review/progressClient";
import { stableJson } from "@/lib/client/persistence/stableJson";
import { useDebouncedCommit } from "@/lib/client/persistence/useDebouncedCommit";
import { useFlushOnPageExit } from "@/lib/client/persistence/useFlushOnPageExit";
import { emitGamificationUpdate } from "@/lib/gamification/browserEvents";
import { useReviewRuntimeStore } from "../runtime/reviewRuntimeStore";
import { mergeRuntimeIntoProgress } from "../runtime/runtimeProgressBridge";
import { reviewDebug, summarizePracticePatch } from "../runtime/reviewDebug";
import { reviewSaveDebug, summarizeWorkspaceForSave } from "../runtime/reviewSaveDebug";
import { getExerciseStateKey } from "../runtime/exerciseKeys";

function isPersistedCardToolKey(toolKey: string) {
    if (typeof toolKey !== "string" || !toolKey.trim()) return false;
    if (toolKey.startsWith("exercise:")) return false;
    return true;
}

function cardIdFromPersistedToolKey(toolKey: string) {
    if (toolKey.startsWith("card:")) return toolKey.replace(/^card:/, "");

    const parts = toolKey.split(":").filter(Boolean);
    if (parts.length >= 2 && parts[parts.length - 1] === "general") {
        return parts[parts.length - 2];
    }

    return parts[parts.length - 1] || toolKey;
}

function cardStateKeyFromPersistedToolKey(toolKey: string) {
    if (toolKey.startsWith("card:")) return toolKey.replace(/^card:/, "");
    if (toolKey.endsWith(":general")) return toolKey.replace(/:general$/, "");
    return toolKey;
}

function normalizeTopicProgressKey(topicId: string | null | undefined) {
    const raw = String(topicId ?? "").trim();
    if (!raw) return "unknown";

    const parts = raw.split(".").filter(Boolean);
    return parts[parts.length - 1] || raw;
}

function isUserSavedState(value: any) {
    return (
        value?.userEdited === true ||
        value?.workspaceOrigin === "user" ||
        value?.workspaceOrigin === "saved"
    );
}

function numericUpdatedAt(value: any) {
    const n = Number(value?.updatedAt ?? 0);
    return Number.isFinite(n) ? n : 0;
}

function chooseSavedValue<T = any>(existing: T | undefined, incoming: T | undefined): T | undefined {
    const a: any = existing;
    const b: any = incoming;

    if (a == null) return incoming;
    if (b == null) return existing;

    const aIsUser = isUserSavedState(a);
    const bIsUser = isUserSavedState(b);

    if (bIsUser && !aIsUser) return incoming;
    if (aIsUser && !bIsUser) return existing;

    if (numericUpdatedAt(b) > numericUpdatedAt(a)) return incoming;

    return existing;
}

function mergeRecordMap<T = any>(
    existing: Record<string, T> | undefined,
    incoming: Record<string, T> | undefined,
): Record<string, T> | undefined {
    if (!existing && !incoming) return undefined;

    const out: Record<string, T> = {
        ...(existing ?? {}),
    };

    for (const [key, value] of Object.entries(incoming ?? {})) {
        out[key] = chooseSavedValue(out[key], value as T) as T;
    }

    return out;
}

function mergeTopicProgressStates(
    existing: ReviewTopicProgress | undefined,
    incoming: ReviewTopicProgress | undefined,
): ReviewTopicProgress {
    const a: any = existing ?? {};
    const b: any = incoming ?? {};

    const runtimeA = a.runtimeStateV2 ?? {};
    const runtimeB = b.runtimeStateV2 ?? {};

    return {
        ...a,
        ...b,

        cardsDone: {
            ...(a.cardsDone ?? {}),
            ...(b.cardsDone ?? {}),
        },

        quizzesDone: {
            ...(a.quizzesDone ?? {}),
            ...(b.quizzesDone ?? {}),
        },

        quizState: mergeRecordMap(a.quizState, b.quizState) ?? {},

        sketchState: mergeRecordMap(a.sketchState, b.sketchState) ?? {},

        toolState: mergeRecordMap(a.toolState, b.toolState) ?? {},

        runtimeStateV2: {
            ...runtimeA,
            ...runtimeB,
            cards: mergeRecordMap(runtimeA.cards, runtimeB.cards) ?? {},
            exercises: mergeRecordMap(runtimeA.exercises, runtimeB.exercises) ?? {},
        },
    };
}

function normalizeProgressTopics(state: ReviewProgressState | null | undefined): ReviewProgressState {
    const base = state ?? emptyReviewProgress();
    const topics = (base as any).topics ?? {};
    const nextTopics: Record<string, ReviewTopicProgress> = {};

    for (const [key, topicState] of Object.entries(topics)) {
        const canonical = normalizeTopicProgressKey(key);
        nextTopics[canonical] = mergeTopicProgressStates(
            nextTopics[canonical],
            topicState as ReviewTopicProgress,
        );
    }

    const activeTopicId = normalizeTopicProgressKey((base as any).activeTopicId);

    return {
        ...base,
        activeTopicId: activeTopicId === "unknown" ? base.activeTopicId : activeTopicId,
        topics: nextTopics,
    };
}

function getTopicProgressState(
    topics: Record<string, ReviewTopicProgress> | null | undefined,
    activeTopicId: string | null | undefined,
): {
    topicKey: string;
    topic: ReviewTopicProgress | null;
} {
    const canonical = normalizeTopicProgressKey(activeTopicId);
    const map = topics ?? {};

    if (map[canonical]) {
        return {
            topicKey: canonical,
            topic: map[canonical],
        };
    }

    const raw = String(activeTopicId ?? "").trim();

    if (raw && map[raw]) {
        return {
            topicKey: raw,
            topic: map[raw],
        };
    }

    const matchKey = Object.keys(map).find(
        (key) => normalizeTopicProgressKey(key) === canonical,
    );

    if (matchKey) {
        return {
            topicKey: matchKey,
            topic: map[matchKey] ?? null,
        };
    }

    return {
        topicKey: canonical,
        topic: null,
    };
}

function getSaveRevision(state: any) {
    const n = Number(state?.__saveRevision ?? 0);
    return Number.isFinite(n) ? n : 0;
}

function canonicalizeExerciseStateKey(
    exerciseKey: string | null | undefined,
    fallbackTopicId?: string | null,
) {
    const raw = String(exerciseKey ?? "").trim();
    if (!raw) return "";

    const parts = raw.split(":").filter(Boolean);
    if (parts.length < 6) return raw;

    const [subjectSlug, moduleSlug, sectionSlug, topicId, cardId, ...exerciseIdParts] = parts;
    if (!exerciseIdParts.length) return raw;

    return getExerciseStateKey(
        {
            subjectSlug,
            moduleSlug,
            sectionSlug,
            topicId: normalizeTopicProgressKey(fallbackTopicId ?? topicId),
            cardId,
        },
        exerciseIdParts.join(":"),
    );
}

function summarizeSavedWorkspaceFiles(workspace: any) {
    if (!workspace || workspace.version !== 2 || !Array.isArray(workspace.nodes)) {
        return { fileCount: 0, contentLength: 0 };
    }

    const files = workspace.nodes.filter((node: any) => node?.kind === "file");
    return {
        fileCount: files.length,
        contentLength: files.reduce(
            (sum: number, node: any) => sum + String(node?.content ?? "").length,
            0,
        ),
    };
}

function looksLikeBetterExerciseRestoreCandidate(existing: any, incoming: any) {
    if (!incoming) return false;
    if (!existing) return true;

    const existingUser = isUserSavedState(existing);
    const incomingUser = isUserSavedState(incoming);
    if (incomingUser !== existingUser) {
        return incomingUser;
    }

    const existingSummary = summarizeSavedWorkspaceFiles(
        existing.workspace ?? existing.codeWorkspace ?? existing.ideWorkspace ?? null,
    );
    const incomingSummary = summarizeSavedWorkspaceFiles(
        incoming.workspace ?? incoming.codeWorkspace ?? incoming.ideWorkspace ?? null,
    );

    if (incomingSummary.fileCount !== existingSummary.fileCount) {
        return incomingSummary.fileCount > existingSummary.fileCount;
    }

    if (incomingSummary.contentLength !== existingSummary.contentLength) {
        return incomingSummary.contentLength > existingSummary.contentLength;
    }

    return numericUpdatedAt(incoming) >= numericUpdatedAt(existing);
}

export function useReviewProgress(args: {
    subjectSlug: string;
    moduleSlug: string;
    locale: string;
    firstTopicId: string;
}) {
    const { subjectSlug, moduleSlug, locale, firstTopicId } = args;

    const [progress, setProgress] = useState<ReviewProgressState>(
        emptyReviewProgress(),
    );
    const [hydrated, setHydrated] = useState(false);

    const [viewTopicId, setViewTopicId] = useState(firstTopicId);
    const [activeTopicId, _setActiveTopicId] = useState(firstTopicId);

    const progressRef = useRef(progress);
    const activeTopicIdRef = useRef(firstTopicId);
    const runtimeSaveTimerRef = useRef<number | null>(null);
    const saveSeqRef = useRef(0);
    const hydrationCompleteRef = useRef(false);

    useEffect(() => {
        progressRef.current = progress;
    }, [progress]);

    const setActiveTopicId = useCallback((id: string) => {
        activeTopicIdRef.current = id;
        _setActiveTopicId(id);
    }, []);

    const store = useReviewRuntimeStore();

    useEffect(() => {
        store.setTopicIds(activeTopicId, viewTopicId);
    }, [activeTopicId, viewTopicId]); // eslint-disable-line react-hooks/exhaustive-deps

    const setProgressSafe = useCallback((updater: any) => {
        setProgress((prev: any) => {
            const next = typeof updater === "function" ? updater(prev) : updater;
            progressRef.current = next;
            return next;
        });
    }, []);

    const payload = useMemo(
        () =>
            buildReviewProgressPayload({
                subjectSlug,
                moduleSlug,
                locale,
                state: progress,
                activeTopicId: normalizeTopicProgressKey(activeTopicId),
            }),
        [subjectSlug, moduleSlug, locale, progress, activeTopicId],
    );

    function makeSaveState(state: ReviewProgressState): ReviewProgressState {
        const latestRuntime = useReviewRuntimeStore.getState();
        const stateWithRuntime = mergeRuntimeIntoProgress(state, latestRuntime);

        const previousRevision = getSaveRevision(stateWithRuntime);
        const nextRevision = Math.max(previousRevision + 1, Date.now());

        const stateToSave = {
            ...(stateWithRuntime as any),
            __saveRevision: nextRevision,
        } as ReviewProgressState;

        progressRef.current = stateToSave;

        return stateToSave;
    }

    const commitProgress = useCallback(
        async (_payload: typeof payload, _body: string, signal: AbortSignal) => {
            if (!subjectSlug || !moduleSlug) return;
            if (!hydrationCompleteRef.current) return;

            try {
                const stateToSave = makeSaveState(progressRef.current);
                const activeTopicKey = normalizeTopicProgressKey(activeTopicIdRef.current);

                const nextPayload = buildReviewProgressPayload({
                    subjectSlug,
                    moduleSlug,
                    locale,
                    state: stateToSave,
                    activeTopicId: activeTopicKey,
                });

                const body = stableJson(nextPayload);
                const latestRuntime = useReviewRuntimeStore.getState();

                console.log("[review-progress] save requested", {
                    reason: "debounce",
                    stateBytes: body.length,
                    saveRevision: getSaveRevision(stateToSave),
                    activeTopicId: activeTopicIdRef.current,
                    activeTopicKey,
                    topicKeys: Object.keys((stateToSave as any).topics ?? {}),
                    runtimeExerciseKeys: Object.keys(latestRuntime.exercises ?? {}),
                    runtimeCardKeys: Object.keys(latestRuntime.cards ?? {}),
                });

                const res = await fetch("/api/review/progress", {
                    method: "PUT",
                    headers: { "Content-Type": "application/json" },
                    body,
                    cache: "no-store",
                    signal,
                });

                if (!res.ok) {
                    throw new Error(`Progress save failed: ${res.status}`);
                }

                const data = await res.json().catch(() => null);
                const gamification = data?.gamification ?? null;

                if (gamification?.summary) {
                    emitGamificationUpdate({
                        source: "review_progress",
                        xpGained: gamification.xpGained ?? 0,
                        leveledUp: Boolean(gamification.leveledUp),
                        streakExtended: Boolean(gamification.streakExtended),
                        summary: gamification.summary,
                    });
                }
            } catch (e: any) {
                if (signal.aborted) return;
                if (e?.name === "AbortError") return;
                throw e;
            }
        },
        [subjectSlug, moduleSlug, locale],
    );

    const {
        prime,
        flush,
        cancel,
        lastCommittedRef,
    } = useDebouncedCommit({
        value: payload,
        enabled: hydrated && Boolean(subjectSlug && moduleSlug),
        delayMs: 900,
        serialize: stableJson,
        commit: commitProgress,
    });

    const putProgressNow = useCallback(
        async (
            state: ReviewProgressState,
            options?: {
                keepalive?: boolean;
                reason?: string;
            },
        ) => {
            if (!subjectSlug || !moduleSlug) return;
            if (!hydrationCompleteRef.current) return;

            const saveSeq = ++saveSeqRef.current;
            const stateToSave = makeSaveState(state);
            const activeTopicKey = normalizeTopicProgressKey(activeTopicIdRef.current);

            const activeTopic = activeTopicKey
                ? (stateToSave as any).topics?.[activeTopicKey]
                : null;

            reviewDebug("9_API_SAVE useReviewProgress.putProgressNow", {
                reason: options?.reason ?? "manual",
                saveSeq,
                subjectSlug,
                moduleSlug,
                activeTopicId: activeTopicIdRef.current,
                activeTopicKey,
                saveRevision: getSaveRevision(stateToSave),
                topicKeys: Object.keys((stateToSave as any).topics ?? {}),
                activeTopicRuntimeExerciseKeys: Object.keys(
                    activeTopic?.runtimeStateV2?.exercises ?? {},
                ),
                activeTopicRuntimeCardKeys: Object.keys(
                    activeTopic?.runtimeStateV2?.cards ?? {},
                ),
                activeTopicQuizCards: Object.keys(activeTopic?.quizState ?? {}),
                activeTopicToolKeys: Object.keys(activeTopic?.toolState ?? {}),
                activeTopicPracticePatchByCard: Object.fromEntries(
                    Object.entries(activeTopic?.quizState ?? {}).map(
                        ([cardId, cardState]: any) => [
                            cardId,
                            Object.fromEntries(
                                Object.entries(cardState?.practiceItemPatch ?? {}).map(
                                    ([key, patch]: any) => [
                                        key,
                                        summarizePracticePatch(patch),
                                    ],
                                ),
                            ),
                        ],
                    ),
                ),
            });

            const nextPayload = buildReviewProgressPayload({
                subjectSlug,
                moduleSlug,
                locale,
                state: stateToSave,
                activeTopicId: activeTopicKey,
            });

            const body = stableJson(nextPayload);
            const latestRuntime = useReviewRuntimeStore.getState();

            console.log("[review-progress] save requested", {
                reason: options?.reason ?? "manual",
                saveSeq,
                stateBytes: body.length,
                saveRevision: getSaveRevision(stateToSave),
                activeTopicId: activeTopicIdRef.current,
                activeTopicKey,
                topicKeys: Object.keys((stateToSave as any).topics ?? {}),
                runtimeExerciseKeys: Object.keys(latestRuntime.exercises ?? {}),
                runtimeCardKeys: Object.keys(latestRuntime.cards ?? {}),
            });

            try {
                const res = await fetch("/api/review/progress", {
                    method: "PUT",
                    headers: { "Content-Type": "application/json" },
                    body,
                    keepalive: options?.keepalive === true,
                    cache: "no-store",
                });

                if (!res.ok) {
                    const message = await res.text().catch(() => "");
                    console.error("[review-progress] save failed", {
                        status: res.status,
                        message,
                    });
                    return;
                }

                if (saveSeq === saveSeqRef.current) {
                    lastCommittedRef.current = body;
                }

                const data = await res.json().catch(() => null);
                const gamification = data?.gamification ?? null;

                if (gamification?.summary) {
                    emitGamificationUpdate({
                        source: "review_progress",
                        xpGained: gamification.xpGained ?? 0,
                        leveledUp: Boolean(gamification.leveledUp),
                        streakExtended: Boolean(gamification.streakExtended),
                        summary: gamification.summary,
                    });
                }
            } catch (error) {
                console.error("[review-progress] save request failed", error);
            }
        },
        [subjectSlug, moduleSlug, locale, lastCommittedRef],
    );

    useEffect(() => {
        if (!subjectSlug || !moduleSlug) return;

        const ctrl = new AbortController();

        hydrationCompleteRef.current = false;
        setHydrated(false);

        (async () => {
            try {
                const fetchedProgress = await fetchReviewProgressGET({
                    subjectSlug,
                    moduleSlug,
                    locale,
                    signal: ctrl.signal,
                });

                const normalizedProgress = normalizeProgressTopics(fetchedProgress);

                setProgressSafe(normalizedProgress);

                if (normalizedProgress.topics) {
                    const resolvedForLog = getTopicProgressState(
                        normalizedProgress.topics,
                        (normalizedProgress as any).activeTopicId || firstTopicId,
                    );

                    console.log("[review-progress] hydrate topic", {
                        activeTopicId: (normalizedProgress as any).activeTopicId || firstTopicId,
                        resolvedTopicKey: resolvedForLog.topicKey,
                        availableTopicKeys: Object.keys(normalizedProgress.topics ?? {}),
                        runtimeExerciseKeys: Object.keys(
                            (resolvedForLog.topic as any)?.runtimeStateV2?.exercises ?? {},
                        ),
                        runtimeCardKeys: Object.keys(
                            (resolvedForLog.topic as any)?.runtimeStateV2?.cards ?? {},
                        ),
                        quizCards: Object.keys(
                            (resolvedForLog.topic as any)?.quizState ?? {},
                        ),
                        toolKeys: Object.keys(
                            (resolvedForLog.topic as any)?.toolState ?? {},
                        ),
                    });

                    Object.entries(normalizedProgress.topics).forEach(([tidRaw, tp]: any) => {
                        const tid = normalizeTopicProgressKey(tidRaw);

                        if (tp.toolState) {
                            Object.entries(tp.toolState).forEach(([toolKey, toolEntry]) => {
                                const key = String(toolKey);
                                const entry = toolEntry as any;
                                if (!entry?.workspace) return;

                                if (key.startsWith("exercise:")) {
                                    const persistedExerciseKey = key.replace(/^exercise:/, "");
                                    const canonicalExerciseKey = canonicalizeExerciseStateKey(
                                        persistedExerciseKey,
                                        tid,
                                    );
                                    const existingExercise =
                                        useReviewRuntimeStore.getState().exercises[canonicalExerciseKey] ?? null;

                                    const incomingExercise = {
                                        exerciseKey: canonicalExerciseKey,
                                        subjectSlug:
                                            entry.subjectSlug ??
                                            existingExercise?.subjectSlug ??
                                            canonicalExerciseKey.split(":")[0] ??
                                            subjectSlug,
                                        moduleSlug:
                                            entry.moduleSlug ??
                                            existingExercise?.moduleSlug ??
                                            canonicalExerciseKey.split(":")[1] ??
                                            moduleSlug,
                                        sectionSlug:
                                            entry.sectionSlug ??
                                            existingExercise?.sectionSlug ??
                                            canonicalExerciseKey.split(":")[2] ??
                                            undefined,
                                        topicId:
                                            entry.topicId ??
                                            existingExercise?.topicId ??
                                            normalizeTopicProgressKey(
                                                canonicalExerciseKey.split(":")[3] ?? tid,
                                            ),
                                        cardId:
                                            entry.cardId ??
                                            existingExercise?.cardId ??
                                            canonicalExerciseKey.split(":")[4] ??
                                            "",
                                        exerciseId:
                                            entry.exerciseId ??
                                            existingExercise?.exerciseId ??
                                            canonicalExerciseKey.split(":").slice(5).join(":"),
                                        language:
                                            entry.lang ??
                                            entry.language ??
                                            entry.workspace?.language ??
                                            existingExercise?.language ??
                                            "python",
                                        workspace: entry.workspace,
                                        codeWorkspace: entry.workspace,
                                        ideWorkspace: entry.workspace,
                                        code: entry.code,
                                        stdin: entry.stdin,
                                        codeStdin: entry.stdin,
                                        lang: entry.lang ?? entry.language ?? entry.workspace?.language,
                                        workspaceStatus: "ready" as const,
                                        userEdited:
                                            entry.userEdited === true ||
                                            entry.workspaceOrigin === "user" ||
                                            entry.workspaceOrigin === "saved",
                                        workspaceOrigin:
                                            entry.workspaceOrigin ??
                                            (entry.userEdited === true ? "user" : "saved"),
                                        starterHash: entry.starterHash,
                                        updatedAt: entry.updatedAt ?? Date.now(),
                                    };

                                    if (
                                        !looksLikeBetterExerciseRestoreCandidate(
                                            existingExercise,
                                            incomingExercise,
                                        )
                                    ) {
                                        return;
                                    }

                                    reviewSaveDebug("hydrate exercise toolState from DB", {
                                        persistedToolKey: key,
                                        persistedExerciseKey,
                                        canonicalExerciseKey,
                                        topicId: tid,
                                        userEdited: incomingExercise.userEdited,
                                        workspaceOrigin: incomingExercise.workspaceOrigin,
                                        workspace: summarizeWorkspaceForSave(entry.workspace),
                                    });

                                    store.ensureExercise({
                                        exerciseKey: canonicalExerciseKey,
                                        subjectSlug: incomingExercise.subjectSlug,
                                        moduleSlug: incomingExercise.moduleSlug,
                                        sectionSlug: incomingExercise.sectionSlug,
                                        topicId: incomingExercise.topicId,
                                        cardId: incomingExercise.cardId,
                                        manifest: incomingExercise as any,
                                        saved: incomingExercise as any,
                                    });

                                    store.patchExercise(canonicalExerciseKey, incomingExercise as any);
                                    return;
                                }

                                if (!isPersistedCardToolKey(key)) return;

                                const cardId = cardIdFromPersistedToolKey(key);
                                const cardKey = cardStateKeyFromPersistedToolKey(key);

                                reviewSaveDebug("hydrate toolState from DB", {
                                    persistedToolKey: key,
                                    hydratedCardKey: cardKey,
                                    topicId: tid,
                                    cardId,
                                    userEdited: entry.userEdited,
                                    workspaceOrigin: entry.workspaceOrigin,
                                    workspace: summarizeWorkspaceForSave(entry.workspace),
                                });

                                store.ensureCard({
                                    cardKey,
                                    topicId: tid,
                                    cardId,
                                    initial: {
                                        cardKey,
                                        topicId: tid,
                                        cardId,
                                        visited: false,
                                        completed: false,
                                        toolKey: key,
                                        toolWorkspace: entry.workspace,
                                        toolCode: entry.code,
                                        toolStdin: entry.stdin,
                                        toolLang: entry.lang,
                                        userEdited: entry.userEdited === true,
                                        workspaceOrigin:
                                            entry.workspaceOrigin ??
                                            (entry.userEdited === true ? "user" : "saved"),
                                        starterHash: entry.starterHash,
                                        updatedAt: entry.updatedAt ?? Date.now(),
                                    } as any,
                                });

                                store.patchCard(cardKey, {
                                    topicId: tid,
                                    cardId,
                                    toolKey: key,
                                    toolWorkspace: entry.workspace,
                                    toolCode: entry.code,
                                    toolStdin: entry.stdin,
                                    toolLang: entry.lang,
                                    userEdited: entry.userEdited === true,
                                    workspaceOrigin:
                                        entry.workspaceOrigin ??
                                        (entry.userEdited === true ? "user" : "saved"),
                                    starterHash: entry.starterHash,
                                } as any);
                            });
                        }

                        if (tp.runtimeStateV2?.cards) {
                            Object.entries(tp.runtimeStateV2.cards).forEach(([ckey, cstate]) => {
                                const savedCard = cstate as any;

                                reviewSaveDebug("hydrate card from DB", {
                                    cardKey: ckey,
                                    topicId: tid,
                                    cardId: savedCard.cardId || "",
                                    userEdited: savedCard.userEdited,
                                    workspaceOrigin: savedCard.workspaceOrigin,
                                    toolKey: savedCard.toolKey,
                                    toolWorkspace: summarizeWorkspaceForSave(savedCard.toolWorkspace),
                                });

                                store.ensureCard({
                                    cardKey: ckey,
                                    topicId: tid,
                                    cardId: savedCard.cardId || "",
                                    initial: {
                                        ...savedCard,
                                        userEdited: savedCard.userEdited === true,
                                        workspaceOrigin:
                                            savedCard.workspaceOrigin ??
                                            (savedCard.userEdited === true ? "user" : "saved"),
                                    },
                                });
                            });
                        }

                        if (tp.runtimeStateV2?.exercises) {
                            Object.entries(tp.runtimeStateV2.exercises).forEach(([ekey, estate]) => {
                                const est = estate as any;
                                const canonicalExerciseKey = canonicalizeExerciseStateKey(
                                    ekey,
                                    est.topicId || tid,
                                );
                                const canonicalTopicId = normalizeTopicProgressKey(est.topicId || tid);

                                store.ensureExercise({
                                    exerciseKey: canonicalExerciseKey,
                                    subjectSlug: est.subjectSlug || subjectSlug || "",
                                    moduleSlug: est.moduleSlug || moduleSlug || "",
                                    sectionSlug: est.sectionSlug,
                                    topicId: canonicalTopicId,
                                    cardId: est.cardId || "",
                                    manifest: estate as any,
                                    saved: {
                                        ...est,
                                        exerciseKey: canonicalExerciseKey,
                                        topicId: canonicalTopicId,
                                    },
                                });

                                if (est.workspace || est.code || est.sketch) {
                                    store.patchExercise(canonicalExerciseKey, {
                                        ...est,
                                        exerciseKey: canonicalExerciseKey,
                                        topicId: canonicalTopicId,
                                        userEdited: est.userEdited === true,
                                        workspaceOrigin:
                                            est.workspaceOrigin ??
                                            (est.userEdited === true ? "user" : "saved"),
                                    });
                                }
                            });
                        }
                    });
                }

                const nextActive = normalizeTopicProgressKey(
                    (normalizedProgress as any).activeTopicId || firstTopicId,
                );

                setActiveTopicId(nextActive);
                setViewTopicId(nextActive);

                prime(
                    buildReviewProgressPayload({
                        subjectSlug,
                        moduleSlug,
                        locale,
                        state: normalizedProgress,
                        activeTopicId: nextActive,
                    }),
                );
            } catch {
                const ep = emptyReviewProgress();

                setProgressSafe(ep);
                setActiveTopicId(firstTopicId);
                setViewTopicId(firstTopicId);

                prime(
                    buildReviewProgressPayload({
                        subjectSlug,
                        moduleSlug,
                        locale,
                        state: ep,
                        activeTopicId: normalizeTopicProgressKey(firstTopicId),
                    }),
                );
            } finally {
                hydrationCompleteRef.current = true;
                setHydrated(true);
            }
        })();

        return () => ctrl.abort();
    }, [
        subjectSlug,
        moduleSlug,
        locale,
        firstTopicId,
        setProgressSafe,
        setActiveTopicId,
        prime,
    ]);

    useFlushOnPageExit(() => {
        if (!hydrated || !hydrationCompleteRef.current) return;

        cancel();

        if (runtimeSaveTimerRef.current != null) {
            window.clearTimeout(runtimeSaveTimerRef.current);
            runtimeSaveTimerRef.current = null;
        }

        const latestProgress = mergeRuntimeIntoProgress(
            progressRef.current,
            useReviewRuntimeStore.getState(),
        );

        progressRef.current = latestProgress;

        void putProgressNow(latestProgress, {
            reason: "page-exit",
            keepalive: false,
        });
    }, hydrated);

    useEffect(() => {
        if (!hydrated || !hydrationCompleteRef.current) return;

        return () => {
            cancel();

            if (runtimeSaveTimerRef.current != null) {
                window.clearTimeout(runtimeSaveTimerRef.current);
                runtimeSaveTimerRef.current = null;
            }

            const latestProgress = mergeRuntimeIntoProgress(
                progressRef.current,
                useReviewRuntimeStore.getState(),
            );

            progressRef.current = latestProgress;

            void putProgressNow(latestProgress, {
                reason: "cleanup",
                keepalive: false,
            });
        };
    }, [hydrated, subjectSlug, moduleSlug, locale, cancel, putProgressNow]);

    useEffect(() => {
        if (!hydrated || !hydrationCompleteRef.current) return;

        const queueRuntimeDbSave = () => {
            if (!hydrationCompleteRef.current) return;

            if (runtimeSaveTimerRef.current != null) {
                window.clearTimeout(runtimeSaveTimerRef.current);
            }

            runtimeSaveTimerRef.current = window.setTimeout(() => {
                runtimeSaveTimerRef.current = null;

                if (!hydrationCompleteRef.current) return;

                const latestRuntime = useReviewRuntimeStore.getState();
                const latestProgress = mergeRuntimeIntoProgress(
                    progressRef.current,
                    latestRuntime,
                );

                progressRef.current = latestProgress;
                setProgressSafe(latestProgress);

                void putProgressNow(latestProgress, {
                    reason: "runtime",
                    keepalive: false,
                });
            }, 1000);
        };

        const unsub = useReviewRuntimeStore.subscribe((runtimeState) => {
            if (!hydrationCompleteRef.current) return;

            setProgressSafe((prev: ReviewProgressState) => {
                const next = mergeRuntimeIntoProgress(prev, runtimeState);
                progressRef.current = next;
                return next;
            });

            queueRuntimeDbSave();
        });

        return () => {
            unsub();

            if (runtimeSaveTimerRef.current != null) {
                window.clearTimeout(runtimeSaveTimerRef.current);
                runtimeSaveTimerRef.current = null;
            }
        };
    }, [hydrated, setProgressSafe, putProgressNow]);

    return {
        hydrated,

        progress,
        setProgress: setProgressSafe,

        activeTopicId,
        setActiveTopicId,

        viewTopicId,
        setViewTopicId,

        flushNow: putProgressNow,
        flush,
    };
}

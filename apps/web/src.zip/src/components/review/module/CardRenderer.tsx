"use client";

import React from "react";
import type { ReviewCard } from "@/lib/subjects/types";
import type {
    ReviewTopicProgress,
    SavedQuizState,
} from "@/lib/subjects/progressTypes";

import MathMarkdown from "@/components/markdown/MathMarkdown";
import QuizBlock from "@/components/review/QuizBlock";
import { buildReviewQuizKey } from "@/lib/subjects/quizClient";

import SketchBlock from "@/components/sketches/subjects/SketchBlock";
import type { SavedSketchState } from "@/components/sketches/subjects/types";
import { useTaggedT } from "@/i18n/tagged";
import {FlowNavMode} from "@/components/review/navigation/FlowNavigator";
import { useReviewRuntimeStore } from "@/components/review/module/runtime/reviewRuntimeStore";
type ReviewCardSpecRecord = Record<string, unknown> | null | undefined;

function GateBanner({ text }: { text: string }) {
    return <div className="mt-2 ui-surface-warn p-2 text-xs font-medium">{text}</div>;
}

function CardTitle({ title }: { title?: string | null }) {
    if (!title) return null;
    return <div className="ui-title-sm">{title}</div>;
}

export default function CardRenderer(props: {
    card: ReviewCard;
    active?: boolean;
    cardIndex?: number;

    done: boolean;
    onMarkDone: () => void;

    prereqsMet: boolean;
    locked?: boolean;

    progressHydrated: boolean;

    savedQuiz: SavedQuizState | null;
    versionStr: string;
    onQuizPass: (quizId: string) => void;
    onQuizStateChange: (quizCardId: string, s: SavedQuizState) => void;
    onQuizReset: (quizCardId: string) => void;

    savedSketch: SavedSketchState | null;
    quizNavMode?: FlowNavMode;
    onSketchStateChange: (sketchCardId: string, s: SavedSketchState) => void;

    onRun?: () => void;
    onReveal?: () => void;
    onSubmit?: () => void;

    cardKey: string;
    topicId: string;
    tp: ReviewTopicProgress;
    routeExerciseId?: string | null;
    defaultToolLanguage?: string;
    onNavigateToExerciseRoute?: (args: { cardId: string; exerciseId: string }) => Promise<void> | void;
}) {
    const ui = useTaggedT("cardUi");
    const tt = useTaggedT();

    const {
        card,
        active = true,
        cardIndex = 0,
        done,
        onMarkDone,
        prereqsMet,
        locked = false,
        progressHydrated,
        savedQuiz,
        versionStr,
        onQuizPass,
        onQuizStateChange,
        onQuizReset,
        savedSketch,
        quizNavMode = "scroll",
        onSketchStateChange,
        cardKey,
        topicId,
        tp,
        routeExerciseId,
        defaultToolLanguage = "python",
        onNavigateToExerciseRoute,
    } = props;

    const ensureCard = useReviewRuntimeStore((s) => s.ensureCard);

    React.useEffect(() => {
        const cardSpec = ("spec" in card ? card.spec : null) as ReviewCardSpecRecord;
        const specRuntime = cardSpec && typeof cardSpec === "object"
            ? (cardSpec.runtime as Record<string, unknown> | undefined)
            : undefined;
        const specWorkspace = cardSpec && typeof cardSpec === "object"
            ? cardSpec.workspace
            : null;

        if (progressHydrated) {
            ensureCard({
                cardKey,
                topicId,
                cardId: card.id,
                initial: {
                    sketch: tp?.sketchState?.[card.id] || null,
                },
                toolLanguage:
                    specRuntime?.kind === "sql" ? "sql" : defaultToolLanguage,
                toolManifest: {
                    workspace: specWorkspace ?? null,
                },
                toolKey: `${cardKey}:general`,
            });
        }
    }, [progressHydrated, cardKey, topicId, card.id, tp, ensureCard, card, defaultToolLanguage]);

    const wrapCls = "ui-surface-muted rounded-none p-4";

    const actionBtn = done ? "ui-btn-ide-success px-3" : "ui-btn-secondary px-3";

    const orderBase = cardIndex * 10000;
    const cardTitle = tt.resolve(card.title ?? null, {}, card.title ?? "");

        const kindLabel = (kind: "quiz" | "project") =>
        kind === "quiz" ? ui.t("kinds.quiz", {}, "quiz") : ui.t("kinds.project", {}, "project");

    function renderQuizLike(kind: "quiz" | "project") {
        const quizCard = card as Extract<ReviewCard, { type: "quiz" | "project" }>;
        const key = buildReviewQuizKey(card.spec, card.id, versionStr);

        const showGate = !done && !prereqsMet;
        const canMountQuizBlock = progressHydrated && (prereqsMet || done);

        const kp = kindLabel(kind);

        const gateText = ui.t(
            "gateBanner",
            { kind: kp },
            `Complete the topic items above to unlock this ${kp}.`,
        );

        const loadingSavedText = ui.t(
            "loadingSaved",
            { kind: kp },
            `Loading saved ${kp} state…`,
        );

        const quizBlockProps =
            kind === "quiz"
                ? {
                    passScore: quizCard.passScore ?? 1.0,
                    sequential: undefined as boolean | undefined,
                    strictSequential: undefined as boolean | undefined,
                    unlimitedAttempts: true,
                }
                : {
                    passScore: 1.0,
                    sequential: true,
                    strictSequential: true,
                    unlimitedAttempts: false,
                };

        return (
            <div className={wrapCls}>
                <CardTitle title={cardTitle} />

                {showGate ? <GateBanner text={gateText} /> : null}

                {!showGate ? (
                    !canMountQuizBlock ? (
                        <div className="mt-2 ui-meta">{loadingSavedText}</div>
                    ) : (
                        <QuizBlock
                            key={key}
                            quizId={card.id}
                            quizCardId={card.id}
                            toolsActive={active}
                            spec={quizCard.spec}
                            quizKey={key}
                            passScore={quizBlockProps.passScore}
                            prereqsMet={prereqsMet}
                            locked={locked}
                            isCompleted={Boolean(done)}
                            initialState={savedQuiz ?? null}
                            onPass={() => onQuizPass(card.id)}
                            onStateChange={(s: SavedQuizState) => onQuizStateChange(card.id, s)}
                            onReset={() => onQuizReset(card.id)}
                            sequential={quizBlockProps.sequential}
                            strictSequential={quizBlockProps.strictSequential}
                            unlimitedAttempts={quizBlockProps.unlimitedAttempts}
                            orderBase={orderBase}
                            navigationMode={quizNavMode}
                            routeExerciseId={routeExerciseId}
                            onNavigateToExerciseRoute={
                                onNavigateToExerciseRoute
                                    ? (exerciseId: string) =>
                                          onNavigateToExerciseRoute({
                                              cardId: card.id,
                                              exerciseId,
                                          })
                                    : undefined
                            }
                        />
                    )
                ) : null}

                {/*{done ? <CompletedBadge text={completedText} /> : null}*/}
            </div>
        );
    }

    if (card.type === "text") {
        const md = tt.resolve(card.markdown ?? "", {}, card.markdown ?? "");
        const btnText = done ? ui.t("actions.readDone", {}, "✓ Read") : ui.t("actions.read", {}, "Mark as read");

        return (
            <div className={wrapCls}>
                <CardTitle title={cardTitle} />
                <MathMarkdown className="ui-math [&_.katex]:text-inherit" content={md} />
                <div className="mt-3 flex justify-end">
                    <button type="button" onClick={onMarkDone} className={actionBtn} data-flow-focus="1">
                        {btnText}
                    </button>
                </div>
            </div>
        );
    }

    if (card.type === "sketch") {
        return (
            <div>
                <SketchBlock
                    key={cardKey}
                    stateKey={cardKey}
                    cardId={card.id}
                    title={card.title}
                    sketchId={card.sketchId}
                    height={card.height}
                    propsPatch={card.props}
                    initialState={savedSketch}
                    onStateChange={(s) => onSketchStateChange(card.id, s)}
                    done={done}
                    onMarkDone={onMarkDone}
                    prereqsMet={prereqsMet}
                    locked={locked}
                />
            </div>
        );
    }

    if (card.type === "video") {
        const provider = card.provider ?? "auto";
        const url = card.url;

        const isFile = /\.(mp4|webm|mov)(\?|#|$)/i.test(url) || provider === "file";

        const caption = tt.resolve(card.captionMarkdown ?? "", {}, card.captionMarkdown ?? "");

        const btnText = done
            ? ui.t("actions.watchedDone", {}, "✓ Watched")
            : ui.t("actions.watched", {}, "Mark watched");

        return (
            <div className={wrapCls}>
                <CardTitle title={cardTitle} />

                <div className="mt-3 ui-surface-muted p-3">
                    {isFile ? (
                        <video className="w-full rounded-xl" controls preload="metadata" poster={card.posterUrl}>
                            <source src={url} />
                        </video>
                    ) : (
                        <iframe
                            className="w-full rounded-xl"
                            style={{ height: 380 }}
                            src={url}
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                        />
                    )}

                    {caption ? (
                        <div className="mt-3">
                            <MathMarkdown className="ui-math [&_.katex]:text-inherit" content={caption} />
                        </div>
                    ) : null}
                </div>

                <div className="mt-3 flex justify-end">
                    <button type="button" onClick={onMarkDone} className={actionBtn} data-flow-focus="1">
                        {btnText}
                    </button>
                </div>
            </div>
        );
    }

    if (card.type === "quiz") return renderQuizLike("quiz");
    if (card.type === "project") return renderQuizLike("project");

    return null;
}

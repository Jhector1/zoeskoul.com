import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it, vi } from "vitest";
import CodeRunner from "@/components/code/runner/CodeRunner";

vi.mock("next-themes", () => ({
    useTheme: () => ({
        resolvedTheme: "dark",
    }),
}));

vi.mock("@/components/markdown/MathMarkdown", () => ({
    default: () => null,
}));

vi.mock("@/components/code/runner/components/EditorPane", () => ({
    default: () => <div data-testid="mock-editor-pane" />,
}));

vi.mock("@/components/code/runner/components/OutputSurface", () => ({
    default: () => <div data-testid="mock-output-surface" />,
}));

vi.mock("@/components/code/runner/components/XtermTerminal", () => ({
    default: () => <div data-testid="mock-xterm-terminal" />,
}));

vi.mock("@/components/code/runner/hooks/useSplitSizing", () => ({
    useSplitSizing: () => ({
        mainH: 320,
        bottomEditorH: 160,
        bottomTermH: 160,
        rightTotalH: 320,
        termW: 240,
        separatorProps: {},
        onPointerDownSplit: vi.fn(),
    }),
}));

vi.mock("@/components/code/runner/hooks/controller/useCodeRunnerController", () => ({
    useCodeRunnerController: () => ({
        busy: false,
        runState: "idle",
        lastResult: null,
        cancelRun: vi.fn(),
        resetTerminal: vi.fn(),
        startRun: vi.fn(),
    }),
}));

vi.mock("@/components/code/runner/hooks/controller/useResolvedRuntime", () => ({
    resolveRuntime: (runtime: unknown) => runtime,
}));

vi.mock("@/components/code/runner/hooks/pty/useWorkspaceTerminalController", () => ({
    useWorkspaceTerminalController: () => ({
        terminalFeed: [],
        inputEnabled: true,
        busy: false,
        sendData: vi.fn(),
        resize: vi.fn(),
        beforeSubmitEnter: vi.fn(),
        afterSubmitEnter: vi.fn(),
        sessionId: "session-1",
        started: true,
        starting: false,
        state: "ready",
        open: vi.fn(),
    }),
}));

describe("CodeRunner terminal-only mode", () => {
    it("renders terminal-only workspace mode without editor or tab switcher", () => {
        const html = renderToStaticMarkup(
            <CodeRunner
                language="python"
                code="print('hi')"
                onChangeCode={vi.fn()}
                onChangeLanguage={vi.fn()}
                showEditor={false}
                showTerminal
                workspaceTerminal={{ enabled: true }}
                isAuthenticated
                editorTestId="editor-pane"
                outputTestId="output-pane"
                showHeaderBar={false}
            />,
        );

        expect(html).toContain('data-testid="output-pane"');
        expect(html).toContain('data-testid="mock-xterm-terminal"');
        expect(html).not.toContain('data-testid="mock-output-surface"');
        expect(html).not.toContain('data-testid="editor-pane"');
        expect(html).not.toContain('data-testid="mock-editor-pane"');
        expect(html).not.toContain("aria-pressed");
        expect(html).not.toContain(">Output<");
        expect(html).not.toContain(">Terminal<");
    });

    it("keeps terminal selected for terminal-only mode across exercise identities", () => {
        const first = renderToStaticMarkup(
            <CodeRunner
                language="python"
                code="print('hi')"
                onChangeCode={vi.fn()}
                onChangeLanguage={vi.fn()}
                showEditor={false}
                showTerminal
                workspaceTerminal={{ enabled: true }}
                isAuthenticated
                exerciseStateKey="exercise-a"
                showHeaderBar={false}
            />,
        );

        const second = renderToStaticMarkup(
            <CodeRunner
                language="python"
                code="print('hi')"
                onChangeCode={vi.fn()}
                onChangeLanguage={vi.fn()}
                showEditor={false}
                showTerminal
                workspaceTerminal={{ enabled: true }}
                isAuthenticated
                exerciseStateKey="exercise-b"
                showHeaderBar={false}
            />,
        );

        expect(first).toContain('data-testid="mock-xterm-terminal"');
        expect(first).not.toContain('data-testid="mock-output-surface"');
        expect(second).toContain('data-testid="mock-xterm-terminal"');
        expect(second).not.toContain('data-testid="mock-output-surface"');
    });

    it("keeps normal editor mode rendering the editor", () => {
        const html = renderToStaticMarkup(
            <CodeRunner
                language="python"
                code="print('hi')"
                onChangeCode={vi.fn()}
                onChangeLanguage={vi.fn()}
                showEditor
                showTerminal={false}
                editorTestId="editor-pane"
                showHeaderBar={false}
            />,
        );

        expect(html).toContain('data-testid="editor-pane"');
        expect(html).toContain('data-testid="mock-editor-pane"');
        expect(html).not.toContain('data-testid="mock-xterm-terminal"');
    });
});

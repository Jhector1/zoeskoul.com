"use client";

import React from "react";
import { NotebookPen, TerminalSquare } from "lucide-react";
import type { ToolSpec, ToolsCtx } from "./types";
import CodeToolPane from "./panes/CodeToolPane";
import{ SqlDialect } from "@/lib/practice/types";
import {RunnerLanguage} from "@zoeskoul/code-contracts";
import NotesToolPane from "@/components/tools/panes/NotesToolPane";
import type { LearningIdeConfig } from "@/lib/ide/learningIdeConfig";
import type { WorkspaceStateV2 } from "@/components/ide/types";

export type CodeToolProps = {
    height: number;
    editorOwnerKey?: string | null;
    toolScopeKey?: string;

    toolHydrated: boolean;
    toolLang: RunnerLanguage;
    toolCode: string;
    toolStdin: string;
    toolWorkspace?: WorkspaceStateV2 | null;
    toolSqlDialect?: SqlDialect;
    ideConfig?: LearningIdeConfig | null;

    onChangeLang?: (l: RunnerLanguage) => void;
    onChangeCode: (c: string) => void;
    onChangeStdin: (s: string) => void;
    onChangeWorkspace?: (workspace: WorkspaceStateV2 | null) => void;
    onChangeSqlDialect?: (d: SqlDialect) => void;

    onBeforeRun?: () => void | Promise<void>;

    sqlSchemaSql?: string;
    sqlSeedSql?: string;
    sqlSetupSql?: string;
    sqlInitialTableSnapshots?: Record<
        string,
        {
            name: string;
            columns: Array<{ name: string; type?: string | null }>;
            rows: unknown[][];
            rowCount: number;
        }
    >;

    showLanguagePicker?: boolean;
    showSqlDialectPicker?: boolean;
};

export type NotesToolProps = {
    noteKey: {
        subjectSlug: string;
        moduleId: string;
        locale: string;
        toolId: string;
        scopeKey: string;
    };
    format?: "markdown" | "plain";
};

export const TOOL_SPECS: ToolSpec[] = [
    {
        id: "code",
        label: "Run",
        Icon: TerminalSquare,
        keepMounted: true,
        enabled: (ctx: ToolsCtx) => ctx.codeEnabled,
        isDefault: (ctx: ToolsCtx) => ctx.codeEnabled,
        render: (props: CodeToolProps) => <CodeToolPane {...props} />,
    },
    {
        id: "notes",
        label: "Notes",
        Icon: NotebookPen,
        keepMounted: true,
        enabled: (_ctx: ToolsCtx) => true,
        isDefault: (ctx: ToolsCtx) => !ctx.codeEnabled,
        render: (props: NotesToolProps) => <NotesToolPane {...props} />,
    },
];

export function getToolSpec(id: string) {
    return TOOL_SPECS.find((t) => t.id === id);
}

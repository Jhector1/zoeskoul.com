import type {
    TopicRecipe,
    BuildSubjectManifestArgs,
    BuildTopicSeedArgs,
    CompileTopicRecipeArgs,
} from "@zoeskoul/curriculum-contracts";
import { buildBaseSubjectManifest } from "../shared/buildBaseSubjectManifest.js";
import type { CourseProfile, CourseProfileAdapter } from "../types.js";
import { buildSqlQueryRecipe } from "./recipes/buildSqlQueryRecipe.js";
import { getSqlModuleDataset } from "./datasetPolicy.js";
import { getSqlDatasetById } from "./datasets/index.js";

export { getSqlModuleDataset } from "./datasetPolicy.js";
export { getSqlDatasetById, listSqlDatasetIds } from "./datasets/index.js";

export const sqlProfile: CourseProfile = {
    id: "sql",
    allowedExerciseKinds: [
        "single_choice",
        "multi_choice",
        "drag_reorder",
        "fill_blank_choice",
        "code_input",
    ],
    allowedRecipeTypes: ["fixed_tests", "template_io", "sql_query"],
    buildModuleRuntimeDefaults(moduleOrder?: number) {
        return {
            kind: "sql",
            datasetId: getSqlModuleDataset(moduleOrder ?? 0),
            fixedSqlDialect: "sqlite",
            resultShape: "table",
        };
    },
    getRecipeRegistry() {
        return { sql_query: buildSqlQueryRecipe };
    },
    validateTopicBundle(bundle) {
        if (!bundle || typeof bundle !== "object") {
            return ["ERROR: topicBundle is missing or invalid"];
        }

        if (!Array.isArray(bundle.cards)) {
            return ["ERROR: topicBundle.cards must be an array"];
        }

        if (!Array.isArray(bundle.sketches)) {
            return ["ERROR: topicBundle.sketches must be an array"];
        }

        if (!Array.isArray(bundle.exercises)) {
            return ["ERROR: topicBundle.exercises must be an array"];
        }

        const issues: string[] = [];
        for (const ex of bundle.exercises) {
            if (
                ex?.kind === "code_input" &&
                ex?.recipe?.type === "sql_query" &&
                !ex?.recipe?.datasetId
            ) {
                issues.push(`ERROR: Exercise ${ex.id} is missing datasetId`);
            }
        }

        return issues;
    },
};

export const sqlProfileAdapter: CourseProfileAdapter = {
    id: "sql",
    buildTopicSeed(args: BuildTopicSeedArgs) {
        const moduleOrder =
            typeof args.module.order === "number" ? args.module.order - 1 : 0;

        const moduleRuntimeDefaults =
            args.module.runtimeDefaults ??
            sqlProfile.buildModuleRuntimeDefaults(moduleOrder);

        const moduleDataset =
            moduleRuntimeDefaults?.kind === "sql" && moduleRuntimeDefaults.datasetId
                ? getSqlDatasetById(moduleRuntimeDefaults.datasetId)
                : null;

        return {
            subjectSlug: args.blueprint.subjectSlug,
            profileId: args.blueprint.profileId,
            moduleSlug: args.module.slug,
            sectionSlug: args.section.slug,
            topicId: args.topic.topicId,
            order: args.topic.order,
            title: args.topic.title,
            summary: args.topic.summary,
            minutes: args.topic.minutes,
            moduleTitle: args.module.title,
            modulePurpose: args.module.purpose,
            moduleObjectives: args.module.learningObjectives,
            guidedExercises: args.module.guidedExercises,
            quizFocus: args.module.quizFocus,
            moduleProject: args.module.moduleProject,
            moduleRuntimeDefaults,
            moduleDataset,
            sectionTitle: args.section.title,
            sourceLocale: args.blueprint.sourceLocale,
            targetLocales: args.blueprint.targetLocales,
        };
    },
    validateTopicRecipe(recipe: TopicRecipe) {
        return sqlProfile.validateTopicBundle(recipe.topicBundle);
    },
    compileTopicRecipe(args: CompileTopicRecipeArgs) {
        return {
            topicBundle: args.recipe.topicBundle,
            messagesByLocale: args.recipe.messagesByLocale,
        };
    },
    buildSubjectManifest(args: BuildSubjectManifestArgs) {
        return buildBaseSubjectManifest(
            args.blueprint,
            args.modules,
            (module: { order: number }) =>
                sqlProfile.buildModuleRuntimeDefaults(Math.max(0, module.order - 1)),
        );
    },
};
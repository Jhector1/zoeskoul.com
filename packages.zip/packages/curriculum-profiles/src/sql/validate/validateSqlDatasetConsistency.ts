import type {
    TopicAuthoringDraft,
    TopicSeed,
} from "@zoeskoul/curriculum-contracts";

export function validateSqlDatasetConsistency(args: {
    seed: TopicSeed;
    draft: TopicAuthoringDraft;
}): string[] {
    const issues: string[] = [];

    const moduleDatasetId =
        args.seed.moduleRuntimeDefaults?.kind === "sql"
            ? args.seed.moduleRuntimeDefaults.datasetId
            : undefined;

    for (const exercise of args.draft.quizDraft) {
        if (exercise.kind !== "code_input") continue;

        const recipeType = exercise.recipeType ?? "sql_query";

        if (recipeType !== "sql_query") {
            issues.push(
                `Exercise ${exercise.id} uses unsupported SQL recipeType "${recipeType}"`,
            );
        }

        const resolvedDatasetId = exercise.datasetId ?? moduleDatasetId;
        if (!resolvedDatasetId) {
            issues.push(
                `Exercise ${exercise.id} is missing datasetId and no module runtime dataset is available`,
            );
        }
    }

    return issues;
}
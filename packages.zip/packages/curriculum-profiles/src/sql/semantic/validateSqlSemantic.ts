import type {
    TopicAuthoringDraft,
    TopicSeed,
} from "@zoeskoul/curriculum-contracts";
import type { SemanticValidationReport } from "../../shared/profileServices.js";
import { makeEmptySemanticValidationReport } from "../../shared/noopReports.js";

export async function validateSqlSemantic(args: {
    seed: TopicSeed;
    draft: TopicAuthoringDraft;
}): Promise<SemanticValidationReport> {
    const report = makeEmptySemanticValidationReport(args.seed.topicId);

    for (const exercise of args.draft.quizDraft) {
        if (exercise.kind !== "code_input") continue;

        if (!exercise.solutionCode.trim()) {
            report.issues.push({
                code: "SQL_EXECUTION_FAILED",
                severity: "error",
                exerciseId: exercise.id,
                message: "SQL solutionCode is empty.",
            });
        }
    }

    report.ok = !report.issues.some((x) => x.severity === "error");
    return report;
}
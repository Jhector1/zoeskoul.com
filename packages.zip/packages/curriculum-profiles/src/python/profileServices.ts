import type { ProfileServices } from "../shared/profileServices.js";
import { pythonTrustPolicy } from "./trustPolicy.js";
import { repairPythonDraft } from "./repair/repairPythonDraft.js";
import { critiquePythonDraft } from "./critique/critiquePythonDraft.js";
import { validatePythonSemantic } from "./semantic/validatePythonSemantic.js";

export const pythonProfileServices: ProfileServices = {
    profileId: "python",

    repairDraft(args) {
        return repairPythonDraft(args);
    },

    critiqueDraft(args) {
        return critiquePythonDraft(args);
    },

    async validateProfile() {
        return [];
    },

    validateSemantic(args) {
        return validatePythonSemantic(args);
    },

    getTrustPolicy() {
        return pythonTrustPolicy;
    },
};
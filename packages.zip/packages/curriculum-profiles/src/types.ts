// import type {
//     ManifestRuntimeDefaults,
//     PlannedModule,
//     ProfileAdapter,
//     TopicBundleManifest,
// } from "@zoeskoul/curriculum-contracts";
//
// export type RecipeHandler<T = any> = (
//     def: any,
//     args: any,
//     resolved: {
//         title: string;
//         prompt: string;
//         hint?: string;
//         starterCode: string;
//         help?: any;
//         expectedExampleMeta?: string;
//         maybeT?: (key: string) => string | undefined;
//     },
// ) => any;
//
// export type CourseProfile = {
//     id: string;
//     allowedExerciseKinds: string[];
//     allowedRecipeTypes: string[];
//     buildModuleRuntimeDefaults(module: PlannedModule): ManifestRuntimeDefaults | null;
//     getRecipeRegistry(): Record<string, RecipeHandler<any>>;
//     validateTopicBundle(bundle: TopicBundleManifest): string[];
// };
//
// export type CourseProfileAdapter = ProfileAdapter;


export type RecipeHandler = (...args: any[]) => any;

export type CourseProfile = {
    id: string;
    allowedExerciseKinds: string[];
    allowedRecipeTypes: string[];
    buildModuleRuntimeDefaults: (moduleOrder?: number) => any;
    getRecipeRegistry: () => Record<string, RecipeHandler>;
    validateTopicBundle: (bundle: any) => string[];
};

export type CourseProfileAdapter = {
    id: string;
    buildTopicSeed: (args: any) => any;
    validateTopicRecipe: (recipe: any) => string[];
    compileTopicRecipe: (args: any) => {
        topicBundle: any;
        messagesByLocale: Record<string, Record<string, unknown>>;
    };
    buildSubjectManifest: (args: any) => any;
};
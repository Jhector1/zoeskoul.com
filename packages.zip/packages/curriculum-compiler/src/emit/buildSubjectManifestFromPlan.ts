// packages/curriculum-compiler/src/emit/buildSubjectManifestFromPlan.ts

import type {
    CourseBlueprint,
    CoursePlan,
    ManifestRuntimeDefaults,
    SqlDialect,
    SubjectManifest,
    SubjectModuleManifest,
    SubjectSectionManifest,
    TopicSeedRuntimeDefaults,
    WorkspaceLanguage,
} from "@zoeskoul/curriculum-contracts";
import type { SubjectShapePack } from "@zoeskoul/curriculum-profiles";
import { moduleOrderToIndex } from "../spec/moduleOrder.js";
import {
    resolveModuleRuntimePolicy,
    runtimePolicyToTopicRuntimeDefaults,
} from "../spec/resolveModuleRuntimePolicy.js";

const SQL_DIALECTS = ["sqlite", "postgres", "mysql", "mssql"] as const;

const CODE_LANGUAGES = [
    "python",
    "java",
    "javascript",
    "c",
    "cpp",
    "bash",
    "web",
] as const;

type ManifestCodeLanguage = Exclude<WorkspaceLanguage, "sql">;

function toSqlDialect(value: string | undefined): SqlDialect | undefined {
    if (!value) return undefined;

    return SQL_DIALECTS.includes(value as SqlDialect)
        ? (value as SqlDialect)
        : undefined;
}

function toManifestCodeLanguage(
    value: string | undefined,
): ManifestCodeLanguage | undefined {
    if (!value) return undefined;

    return CODE_LANGUAGES.includes(value as ManifestCodeLanguage)
        ? (value as ManifestCodeLanguage)
        : undefined;
}

function toManifestRuntimeDefaults(
    runtimeDefaults: TopicSeedRuntimeDefaults | null | undefined,
): ManifestRuntimeDefaults | undefined {
    if (!runtimeDefaults) return undefined;

    if (runtimeDefaults.kind === "sql") {
        return {
            kind: "sql",
            datasetId: runtimeDefaults.datasetId,
            fixedSqlDialect:
                toSqlDialect(runtimeDefaults.fixedSqlDialect) ?? "sqlite",
            resultShape: "table",
        };
    }

    if (runtimeDefaults.kind === "code") {
        return {
            kind: "code",
            language: toManifestCodeLanguage(runtimeDefaults.language),
        };
    }

    return undefined;
}

export function buildSubjectManifestFromPlan(args: {
    blueprint: CourseBlueprint;
    plan: CoursePlan;
    shape: SubjectShapePack;
}): SubjectManifest {
    const { blueprint, plan, shape } = args;
    const kp = shape.subjectManifest.keyPatterns;

    const modules: SubjectModuleManifest[] = plan.modules.map((module) => {
        const moduleIndex = moduleOrderToIndex(module.order);
        const logicalModuleSlug = shape.subjectManifest.moduleSlug(moduleIndex);

        const resolvedRuntimePolicy = resolveModuleRuntimePolicy({
            blueprint,
            module: {
                moduleSlug: module.moduleSlug,
                order: module.order,
                runtimePolicy: module.runtimePolicy,
            },
        });

        const topicRuntimeDefaults = runtimePolicyToTopicRuntimeDefaults({
            profileId: blueprint.profileId,
            runtimePolicy: resolvedRuntimePolicy,
        });

        const runtimeDefaults =
            toManifestRuntimeDefaults(topicRuntimeDefaults);

        const sections: SubjectSectionManifest[] = module.sections.map(
            (section) => {
                const sectionSlug = shape.subjectManifest.sectionSlug(
                    moduleIndex,
                    section.order,
                );

                return {
                    slug: sectionSlug,
                    order: section.order,
                    titleKey: kp.sectionTitleKey(
                        blueprint.subjectSlug,
                        logicalModuleSlug,
                        sectionSlug,
                    ),
                    descriptionKey: kp.sectionDescriptionKey(
                        blueprint.subjectSlug,
                        logicalModuleSlug,
                        sectionSlug,
                    ),
                    meta: {
                        module: moduleIndex,
                        weeksKey: kp.sectionWeeksKey(
                            blueprint.subjectSlug,
                            logicalModuleSlug,
                            sectionSlug,
                        ),
                        bulletKeys: [0, 1, 2, 3].map((i) =>
                            kp.sectionBulletKey(
                                blueprint.subjectSlug,
                                logicalModuleSlug,
                                sectionSlug,
                                i,
                            ),
                        ),
                    },
                    topics: section.topics.map((topic) => topic.topicId),
                };
            },
        );

        return {
            slug: logicalModuleSlug,
            prefix: shape.subjectManifest.modulePrefix(moduleIndex),
            order: moduleIndex,
            titleKey: kp.moduleTitleKey(
                blueprint.subjectSlug,
                logicalModuleSlug,
            ),
            descriptionKey: kp.moduleDescriptionKey(
                blueprint.subjectSlug,
                logicalModuleSlug,
            ),
            weekStart: module.weekStart ?? null,
            weekEnd: module.weekEnd ?? null,
            accessOverride: module.order <= 2 ? "free" : null,
            runtimeDefaults,
            meta: {
                estimatedMinutes: module.sections
                    .flatMap((section) => section.topics)
                    .reduce((sum, topic) => sum + topic.minutes, 0),
                prereqKeys:
                    moduleIndex > 0
                        ? [
                            kp.moduleTitleKey(
                                blueprint.subjectSlug,
                                shape.subjectManifest.moduleSlug(
                                    moduleIndex - 1,
                                ),
                            ),
                        ]
                        : [],
                outcomeKeys: [0, 1, 2, 3].map((i) =>
                    kp.moduleOutcomeKey(
                        blueprint.subjectSlug,
                        logicalModuleSlug,
                        i,
                    ),
                ),
                whyKeys: [0, 1].map((i) =>
                    kp.moduleWhyKey(
                        blueprint.subjectSlug,
                        logicalModuleSlug,
                        i,
                    ),
                ),
            },
            sections,
        };
    });

    return {
        subject: {
            slug: blueprint.subjectSlug,
            genKey: shape.subjectManifest.genKey,
            order: blueprint.subjectSlug === "sql" ? 20 : 30,
            accessPolicy: shape.subjectManifest.accessPolicyDefault,
            status: shape.subjectManifest.statusDefault,
            imagePublicId: null,
            imageAlt: null,
            titleKey: kp.subjectTitleKey(blueprint.subjectSlug),
            descriptionKey: kp.subjectDescriptionKey(blueprint.subjectSlug),
            meta: {
                curriculum: {
                    plannedModuleCount: plan.modules.length,
                    isTerminalRelease: false,
                    moreComingMessageKey: kp.subjectMoreComingKey(
                        blueprint.subjectSlug,
                    ),
                },
                completionPolicy: shape.subjectManifest.completionPolicy,
            },
        },
        modules,
    };
}
import type { LocaleCode } from "./locales.js";
import type { ManifestIdeServiceConfig } from "./ide-services.js";
import {CourseGenerationPolicy, ModulePedagogyPolicy, TopicPedagogyPolicy, WorkspaceProfile} from "./workspace";
import {SqlDialect} from "./manifest";

export type CourseProfileId =
    | "sql"
    | "python"
    | "math"
    | "language"
    | "web"
    | "data_science";

export type BlueprintRuntimePolicy = {
  datasetStrategy?: "module_based" | "topic_based" | "manual";
  datasetId?: string;
  preferredDatasetId?: string;
  moduleDatasetIds?: Record<string, string>;   sqlDialect?: SqlDialect;
  resultShape?: "table";
};
export type BlueprintModuleScheduleEntry = {
  moduleNumber: number;
  weekStart: number;
  weekEnd: number;
};
export type CourseBlueprint = {
  subjectSlug: string;
  catalogSlug?: string;
  moduleSchedule?: BlueprintModuleScheduleEntry[];
  profileId: CourseProfileId;
  sourceLocale: "en";
  targetLocales: LocaleCode[];
  title: string;
  description?: string;
  level: "beginner" | "intermediate" | "advanced";
  audience: string[];
  goals: string[];
  teachingStyle?: {
    tone?: string;
    quizWeight?: number;
    projectWeight?: number;
    codeInputWeight?: number;
  };
  constraints: {
    moduleCount: number;
    topicsPerModuleMin: number;
    topicsPerModuleMax: number;
  };
  seedModules?: string[];
  runtimePolicy?: BlueprintRuntimePolicy;
  idePolicy?: {
    defaultServices?: ManifestIdeServiceConfig;
    moduleServiceDefaults?: Record<string, ManifestIdeServiceConfig>;
  };
  versioning?: {
    family: string;
    version: number;
    status: "draft" | "active" | "legacy" | "disabled";
    defaultForNewEnrollments?: boolean;
    supersedes?: string | null;
    supersededBy?: string | null;
  };

  workspaceProfileId?: string;
  workspaceOverrides?: Partial<WorkspaceProfile>;

  courseGenerationPolicy?: CourseGenerationPolicy;

  modulePolicies?: ModulePedagogyPolicy[];
  topicPolicies?: Record<string, TopicPedagogyPolicy>;
};

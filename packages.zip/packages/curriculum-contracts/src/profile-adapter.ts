




import type { TopicSeed, TopicSeedRuntimeDefaults } from "./topic-seed.js";

export type BuildTopicSeedArgs = {
  blueprint: {
    subjectSlug: string;
    profileId: string;
    sourceLocale: string;
    targetLocales: string[];
  };
  module: {
    slug: string;
    title: string;
    order: number;
    purpose?: string;
    learningObjectives?: string[];
    guidedExercises?: string[];
    quizFocus?: string[];
    moduleProject?: string;
    runtimeDefaults?: TopicSeedRuntimeDefaults | null;
  };
  section: {
    slug: string;
    title: string;
    order: number;
  };
  topic: {
    topicId: string;
    order: number;
    title: string;
    summary: string;
    minutes: number;
  };
};

export type CompileTopicRecipeArgs = {
  seed: TopicSeed;
  recipe: any;
  sourceLocale: string;
  targetLocales: string[];
};

export type BuildSubjectManifestArgs = {
  blueprint: any;
  modules: any[];
};

export type CourseProfileAdapter = {
  id: string;
  buildTopicSeed(args: BuildTopicSeedArgs): TopicSeed;
  validateTopicRecipe(recipe: any): string[];
  compileTopicRecipe(args: CompileTopicRecipeArgs): {
    topicBundle: any;
    messagesByLocale: Record<string, Record<string, unknown>>;
  };
  buildSubjectManifest(args: BuildSubjectManifestArgs): any;
};
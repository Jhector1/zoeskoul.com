import { runLocalCode } from "./localRunner.js";
import { getCodeRunner } from "./runner.js";
import type { ProgrammingExpected, SemanticCheck } from "@zoeskoul/practice-checks";

const DEFAULT_LIMITS = {
    timeoutMs: 4000,
} as const;

const SENTINEL = "__ZOE_SEMANTIC_RESULT__";

function buildPythonSemanticHarness(args: {
    userCode: string;
    semanticChecks: SemanticCheck[];
}) {
    const userCodeJson = JSON.stringify(args.userCode ?? "");
    const checksJson = JSON.stringify(args.semanticChecks ?? []);

    return `
import contextlib
import io
import json

_SENTINEL = ${JSON.stringify(SENTINEL)}
_USER_CODE = ${userCodeJson}
_CHECKS = ${checksJson}

_user_stdout_buffer = io.StringIO()
_env = {"__name__": "__main__"}
_errors = []

def _fail(message):
    _errors.append(str(message))

def _get_class(class_name):
    value = _env.get(class_name)
    if not isinstance(value, type):
        return None
    return value

def _make_instance(class_name, args):
    cls = _get_class(class_name)
    if cls is None:
        raise AssertionError(f"Define a class named {class_name}.")
    return cls(*list(args or []))

try:
    with contextlib.redirect_stdout(_user_stdout_buffer):
        exec(_USER_CODE, _env, _env)
except BaseException as exc:
    print(_SENTINEL + json.dumps({
        "ok": False,
        "errors": [f"Your program crashed before it could be checked: {type(exc).__name__}: {exc}"],
        "userStdout": _user_stdout_buffer.getvalue(),
    }, ensure_ascii=False))
    raise SystemExit(0)

for check in _CHECKS:
    ctype = check.get("type")
    try:
        if ctype == "defines_class":
            class_name = check.get("className")
            if _get_class(class_name) is None:
                _fail(check.get("message") or f"Define a class named {class_name}.")
        elif ctype == "constructible":
            _make_instance(check.get("className"), check.get("constructorArgs") or [])
        elif ctype == "instance_attributes":
            instance = _make_instance(check.get("className"), check.get("constructorArgs") or [])
            for attr in check.get("attributes") or []:
                if not hasattr(instance, attr):
                    _fail(check.get("message") or f"Instances should have a {attr!r} attribute.")
        elif ctype == "method_returns":
            instance = _make_instance(check.get("className"), check.get("constructorArgs") or [])
            method_name = check.get("methodName")
            method_args = check.get("methodArgs") or []
            expected = check.get("expected")
            if not hasattr(instance, method_name):
                _fail(check.get("message") or f"Add a method named {method_name}.")
            else:
                method = getattr(instance, method_name)
                if not callable(method):
                    _fail(check.get("message") or f"{method_name} should be a method.")
                else:
                    actual = method(*list(method_args))
                    if actual != expected:
                        _fail(check.get("message") or f"{method_name}() should return {expected!r}, but got {actual!r}.")
        elif ctype == "created_instances":
            class_name = check.get("className")
            min_count = int(check.get("min") or 1)
            cls = _get_class(class_name)
            if cls is None:
                _fail(check.get("message") or f"Define a class named {class_name}.")
            else:
                count = 0
                for value in _env.values():
                    try:
                        if isinstance(value, cls):
                            count += 1
                    except Exception:
                        pass
                if count < min_count:
                    _fail(check.get("message") or f"Create at least {min_count} instance(s) of {class_name}.")
        elif ctype == "printed_line_count":
            min_count = int(check.get("min") or 1)
            lines = [line.strip() for line in _user_stdout_buffer.getvalue().splitlines() if line.strip()]
            if len(lines) < min_count:
                _fail(check.get("message") or f"Print at least {min_count} non-empty line(s).")
        else:
            _fail(f"Unsupported semantic check type: {ctype}")
    except BaseException as exc:
        _fail(check.get("message") or f"Semantic check failed: {type(exc).__name__}: {exc}")

print(_SENTINEL + json.dumps({
    "ok": len(_errors) == 0,
    "errors": _errors,
    "userStdout": _user_stdout_buffer.getvalue(),
}, ensure_ascii=False))
`.trimStart();
}

function parseSemanticResult(stdout: string) {
    const lines = String(stdout ?? "").split(/\r?\n/);
    const line = [...lines].reverse().find((value) => value.startsWith(SENTINEL));
    if (!line) return null;

    try {
        return JSON.parse(line.slice(SENTINEL.length)) as {
            ok: boolean;
            errors?: string[];
            userStdout?: string;
        };
    } catch {
        return null;
    }
}

export async function validatePythonSemanticCode(args: {
    expected: ProgrammingExpected;
    solutionCode: string;
}): Promise<
    | { ok: true }
    | {
        ok: false;
        reason: "runner_unavailable" | "execution_failed" | "semantic_mismatch";
        message: string;
      }
> {
    const runner = getCodeRunner() ?? runLocalCode;
    const semanticChecks =
        args.expected.checkMode === "semantic" ? args.expected.semanticChecks : [];

    const run = await runner({
        language: "python",
        code: buildPythonSemanticHarness({
            userCode: args.solutionCode,
            semanticChecks,
        }),
        stdin: "",
        limits: DEFAULT_LIMITS,
    });

    if (!run.ok) {
        return {
            ok: false,
            reason:
                run.error?.includes("No local compiler-side runner is implemented")
                    ? "runner_unavailable"
                    : "execution_failed",
            message: run.error ?? "Semantic runner failed.",
        };
    }

    const parsed = parseSemanticResult(run.stdout ?? "");
    if (!parsed) {
        return {
            ok: false,
            reason: "execution_failed",
            message: "Semantic checker did not return a valid result.",
        };
    }

    if (!parsed.ok) {
        return {
            ok: false,
            reason: "semantic_mismatch",
            message: parsed.errors?.[0] ?? "Solution did not satisfy semantic checks.",
        };
    }

    return { ok: true };
}
